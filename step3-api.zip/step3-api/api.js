/**
 * api.js
 *
 * Express REST API for the JobCrawler job board.
 * Reads from PostgreSQL and returns JSON.
 *
 * Run: node step3-api/api.js
 *
 * Endpoints:
 *   GET /api/jobs           -- list jobs with filters + pagination
 *   GET /api/jobs/:id       -- single job detail
 *   GET /api/companies      -- list all companies
 *   GET /api/stats          -- dashboard counts
 */

const path    = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const express = require('express');
const cors    = require('cors');
const { Pool } = require('pg');

const app  = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());


// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

function send(res, data) {
  res.json({ ok: true, ...data });
}

function fail(res, status, message) {
  res.status(status).json({ ok: false, error: message });
}

// Canadian cities and provinces used for location matching
const CANADA_LOCATION_TERMS = [
  'canada', 'ontario', 'british columbia', 'alberta', 'quebec',
  'manitoba', 'saskatchewan', 'nova scotia', 'new brunswick',
  'toronto', 'vancouver', 'montreal', 'calgary', 'ottawa',
  'edmonton', 'waterloo', 'winnipeg', 'hamilton', 'kitchener',
  'london ontario', 'victoria bc', 'halifax',
  ', on', ', bc', ', qc', ', ab', ', mb', ', sk',
];

// US cities/states that frequently appear as "Remote, CA" etc.
// We exclude these when someone filters for Canada
const US_LOCATION_TERMS = [
  'usa', 'united states', 'u.s.', 'u.s.a',
  'california', 'san francisco', 'los angeles', 'san jose', 'san diego',
  'new york', 'nyc', 'brooklyn', 'manhattan',
  'seattle', 'washington state',
  'boston', 'massachusetts',
  'chicago', 'illinois',
  'austin', 'dallas', 'houston', 'texas',
  'denver', 'colorado',
  'atlanta', 'georgia',
  'miami', 'florida',
  'portland', 'oregon',
  'minneapolis', 'minnesota',
  'phoenix', 'arizona',
  'las vegas', 'nevada',
  ', ca', ', ny', ', tx', ', wa', ', ma',
  ', co', ', il', ', ga', ', fl', ', or',
  ', az', ', nv', ', mn', ', nc', ', va',
];

function buildCanadaFilter() {
  const canadaChecks  = CANADA_LOCATION_TERMS.map(t => `j.location ILIKE '%${t}%'`).join('\n        OR ');
  const usExclusions  = US_LOCATION_TERMS.map(t => `j.location NOT ILIKE '%${t}%'`).join('\n          AND ');

  return `(
      -- job is in a known Canadian city or province
      (${canadaChecks})
      OR
      -- job is fully remote and location does not mention any US city/state
      (
        j.remote = 'remote'
        AND (j.location IS NULL OR j.location = '' OR (${usExclusions}))
      )
    )`;
}

function buildFilters(query, startIdx = 1) {
  const conditions = ['j.is_active = TRUE'];
  const values     = [];
  let   idx        = startIdx;

  if (query.q) {
    conditions.push(
      `(j.title ILIKE $${idx} OR j.company_name ILIKE $${idx} OR j.raw_description ILIKE $${idx})`
    );
    values.push(`%${query.q}%`);
    idx++;
  }

  if (query.ats) {
    conditions.push(`j.ats = $${idx}`);
    values.push(query.ats);
    idx++;
  }

  if (query.remote) {
    conditions.push(`j.remote = $${idx}`);
    values.push(query.remote);
    idx++;
  }

  if (query.seniority) {
    conditions.push(`j.seniority = $${idx}`);
    values.push(query.seniority);
    idx++;
  }

  if (query.specialty) {
    conditions.push(`j.specialty = $${idx}`);
    values.push(query.specialty);
    idx++;
  }

  if (query.canada === 'true') {
    // two-layer check:
    // 1. location text must match a Canadian city/province
    //    OR be a genuinely open remote role with no US location markers
    // 2. the AI flag must also agree
    conditions.push(buildCanadaFilter());
  }

  if (query.visa === 'true') {
    conditions.push(`j.visa_sponsored = TRUE`);
  }

  if (query.stack) {
    const techs = query.stack.split(',').map(t => t.trim().toLowerCase());
    conditions.push(`j.tech_stack && $${idx}::text[]`);
    values.push(techs);
    idx++;
  }

  if (query.salary_min) {
    conditions.push(`j.salary_max >= $${idx}`);
    values.push(parseInt(query.salary_min, 10));
    idx++;
  }

  if (query.days) {
    conditions.push(`j.date_posted >= NOW() - INTERVAL '${parseInt(query.days, 10)} days'`);
  }

  const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
  return { where, values, nextIdx: idx };
}


// ---------------------------------------------------------------------------
// GET /api/jobs
// ---------------------------------------------------------------------------

app.get('/api/jobs', async (req, res) => {
  try {
    const page   = Math.max(1, parseInt(req.query.page  || '1',  10));
    const limit  = Math.min(100, parseInt(req.query.limit || '25', 10));
    const offset = (page - 1) * limit;
    const sort   = req.query.sort === 'salary'
      ? 'j.salary_max DESC NULLS LAST'
      : 'j.date_posted DESC NULLS LAST';

    const { where, values, nextIdx } = buildFilters(req.query);

    const countRes = await pool.query(
      `SELECT COUNT(*) FROM jobs j ${where}`,
      values
    );
    const total = parseInt(countRes.rows[0].count, 10);

    const jobsRes = await pool.query(
      `SELECT
         j.id, j.external_id, j.company_slug, j.company_name, j.ats,
         j.title, j.location, j.apply_url, j.date_posted,
         j.seniority, j.specialty, j.tech_stack,
         j.salary_min, j.salary_max, j.remote, j.yoe_min,
         j.visa_sponsored, j.canada_eligible, j.created_at
       FROM jobs j
       ${where}
       ORDER BY ${sort}
       LIMIT $${nextIdx} OFFSET $${nextIdx + 1}`,
      [...values, limit, offset]
    );

    send(res, { total, page, limit, pages: Math.ceil(total / limit), jobs: jobsRes.rows });
  } catch (err) {
    console.error('/api/jobs error:', err.message);
    fail(res, 500, err.message);
  }
});


// ---------------------------------------------------------------------------
// GET /api/jobs/:id
// ---------------------------------------------------------------------------

app.get('/api/jobs/:id', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM jobs WHERE id = $1 AND is_active = TRUE`,
      [req.params.id]
    );
    if (result.rows.length === 0) return fail(res, 404, 'job not found');
    send(res, { job: result.rows[0] });
  } catch (err) {
    console.error('/api/jobs/:id error:', err.message);
    fail(res, 500, err.message);
  }
});


// ---------------------------------------------------------------------------
// GET /api/companies
// ---------------------------------------------------------------------------

app.get('/api/companies', async (req, res) => {
  try {
    const page   = Math.max(1, parseInt(req.query.page  || '1',  10));
    const limit  = Math.min(100, parseInt(req.query.limit || '50', 10));
    const offset = (page - 1) * limit;

    const conditions = ['c.active = TRUE'];
    const values     = [];
    let   idx        = 1;

    if (req.query.ats) {
      conditions.push(`c.ats = $${idx++}`);
      values.push(req.query.ats);
    }

    if (req.query.q) {
      conditions.push(`c.name ILIKE $${idx++}`);
      values.push(`%${req.query.q}%`);
    }

    const where = 'WHERE ' + conditions.join(' AND ');

    const countRes = await pool.query(
      `SELECT COUNT(*) FROM companies c ${where}`, values
    );
    const total = parseInt(countRes.rows[0].count, 10);

    const result = await pool.query(
      `SELECT
         c.id, c.slug, c.name, c.ats, c.board_url,
         c.last_crawled, c.created_at,
         COUNT(j.id) AS job_count
       FROM companies c
       LEFT JOIN jobs j
         ON j.company_slug = c.slug AND j.ats = c.ats AND j.is_active = TRUE
       ${where}
       GROUP BY c.id
       ORDER BY COUNT(j.id) DESC, c.name ASC
       LIMIT $${idx} OFFSET $${idx + 1}`,
      [...values, limit, offset]
    );

    send(res, { total, page, limit, pages: Math.ceil(total / limit), companies: result.rows });
  } catch (err) {
    console.error('/api/companies error:', err.message);
    fail(res, 500, err.message);
  }
});


// ---------------------------------------------------------------------------
// GET /api/stats
// ---------------------------------------------------------------------------

app.get('/api/stats', async (req, res) => {
  try {
    const canadaFilter = buildCanadaFilter();

    const [
      jobCount, companyCount, remoteCount, canadaCount, freshCount,
      byAts, bySeniority, bySpecialty, byRemote, topStacks, topCompanies,
    ] = await Promise.all([
      pool.query(`SELECT COUNT(*) FROM jobs WHERE is_active = TRUE`),
      pool.query(`SELECT COUNT(*) FROM companies WHERE active = TRUE`),
      pool.query(`SELECT COUNT(*) FROM jobs WHERE is_active = TRUE AND remote = 'remote'`),
      pool.query(`SELECT COUNT(*) FROM jobs j WHERE j.is_active = TRUE AND ${canadaFilter}`),
      pool.query(`SELECT COUNT(*) FROM jobs WHERE is_active = TRUE AND date_posted >= NOW() - INTERVAL '7 days'`),
      pool.query(`SELECT ats, COUNT(*) as count FROM jobs WHERE is_active = TRUE GROUP BY ats ORDER BY count DESC`),
      pool.query(`SELECT seniority, COUNT(*) as count FROM jobs WHERE is_active = TRUE AND seniority IS NOT NULL GROUP BY seniority ORDER BY count DESC`),
      pool.query(`SELECT specialty, COUNT(*) as count FROM jobs WHERE is_active = TRUE AND specialty IS NOT NULL GROUP BY specialty ORDER BY count DESC`),
      pool.query(`SELECT remote, COUNT(*) as count FROM jobs WHERE is_active = TRUE AND remote IS NOT NULL GROUP BY remote ORDER BY count DESC`),
      pool.query(`SELECT unnest(tech_stack) as tech, COUNT(*) as count FROM jobs WHERE is_active = TRUE GROUP BY tech ORDER BY count DESC LIMIT 20`),
      pool.query(`SELECT company_name, COUNT(*) as job_count FROM jobs WHERE is_active = TRUE GROUP BY company_name ORDER BY job_count DESC LIMIT 10`),
    ]);

    send(res, {
      totals: {
        jobs:        parseInt(jobCount.rows[0].count, 10),
        companies:   parseInt(companyCount.rows[0].count, 10),
        remote_jobs: parseInt(remoteCount.rows[0].count, 10),
        canada_jobs: parseInt(canadaCount.rows[0].count, 10),
        fresh_7days: parseInt(freshCount.rows[0].count, 10),
      },
      breakdown: {
        by_ats:       byAts.rows,
        by_seniority: bySeniority.rows,
        by_specialty: bySpecialty.rows,
        by_remote:    byRemote.rows,
      },
      top_stacks:    topStacks.rows,
      top_companies: topCompanies.rows,
    });
  } catch (err) {
    console.error('/api/stats error:', err.message);
    fail(res, 500, err.message);
  }
});


// ---------------------------------------------------------------------------
// GET /api/health
// ---------------------------------------------------------------------------

app.get('/api/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ ok: true, db: 'connected', time: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ ok: false, db: 'disconnected', error: err.message });
  }
});

app.use((req, res) => {
  fail(res, 404, `route not found: ${req.method} ${req.path}`);
});

app.listen(PORT, () => {
  console.log(`api running on http://localhost:${PORT}`);
  console.log('');
  console.log('endpoints:');
  console.log(`  GET http://localhost:${PORT}/api/health`);
  console.log(`  GET http://localhost:${PORT}/api/stats`);
  console.log(`  GET http://localhost:${PORT}/api/jobs`);
  console.log(`  GET http://localhost:${PORT}/api/jobs/:id`);
  console.log(`  GET http://localhost:${PORT}/api/companies`);
});