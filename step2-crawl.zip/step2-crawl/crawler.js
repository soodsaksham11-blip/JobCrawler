/**
 * crawler.js
 *
 * Reads companies.json, crawls each ATS API 5 at a time,
 * extracts structured data with Gemini, and saves to PostgreSQL.
 *
 * Run: node step2-crawl/crawler.js
 */

const fs   = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const cron = require('node-cron');

const { fetchJobs }     = require('./ats-fetchers');
const { extractWithAI } = require('./ai-extractor');
const { hashJob }       = require('./dedup');
const db                = require('./db');

const CONCURRENCY     = parseInt(process.env.CRAWL_CONCURRENCY   || '5',  10);
const DELAY_MS        = parseInt(process.env.CRAWL_DELAY_MS       || '300', 10);
const MAX_JOBS_PER_CO = parseInt(process.env.MAX_JOBS_PER_COMPANY || '50',  10);
const COMPANIES_FILE  = path.join(__dirname, '..', 'companies.json');

function loadCompanies() {
  if (!fs.existsSync(COMPANIES_FILE)) {
    throw new Error(`companies.json not found -- run step 1 first`);
  }
  const all = JSON.parse(fs.readFileSync(COMPANIES_FILE, 'utf-8'));
  return all.filter((c) => c.active !== false && ['greenhouse','lever','ashby'].includes(c.ats));
}

async function processCompany(company) {
  try {
    await db.upsertCompany(company);

    const rawJobs = await fetchJobs(company);
    if (rawJobs.length === 0) {
      await db.markCompanyCrawled(company.slug, company.ats);
      return { slug: company.slug, fetched: 0, saved: 0 };
    }

    const jobs = rawJobs.slice(0, MAX_JOBS_PER_CO);
    let saved = 0;
    const activeIds = [];

    for (const raw of jobs) {
      try {
        if (!raw.external_id || !raw.title) continue;
        activeIds.push(raw.external_id);

        const exists   = await db.jobExists(raw.external_id, company.ats);
        const hash     = hashJob(raw.title, company.slug, raw.location);
        const hashSeen = await db.hashExists(hash);

        if (exists || hashSeen) continue;

        const extracted = await extractWithAI(raw.raw_description);

        await db.insertJob({
          ...raw,
          ...extracted,
          company_slug: company.slug,
          company_name: company.name,
          ats:          company.ats,
          content_hash: hash,
        });

        saved++;
        await sleep(DELAY_MS);
      } catch (err) {
        console.error(`    job error: ${err.message}`);
      }
    }

    await db.markJobsInactive(company.slug, company.ats, activeIds);
    await db.markCompanyCrawled(company.slug, company.ats);

    return { slug: company.slug, fetched: jobs.length, saved };
  } catch (err) {
    console.error(`[${company.ats}] ${company.slug} failed: ${err.message}`);
    return { slug: company.slug, fetched: 0, saved: 0 };
  }
}

async function runCrawl() {
  const started = Date.now();
  console.log(`crawl started at ${new Date().toISOString()}`);

  const companies = loadCompanies();
  console.log(`loaded ${companies.length} companies`);
  console.log(`concurrency: ${CONCURRENCY}  delay: ${DELAY_MS}ms  max jobs/company: ${MAX_JOBS_PER_CO}`);
  console.log('');

  let totalFetched = 0;
  let totalSaved   = 0;
  let done         = 0;

  for (let i = 0; i < companies.length; i += CONCURRENCY) {
    const chunk   = companies.slice(i, i + CONCURRENCY);
    const results = await Promise.all(chunk.map(processCompany));

    for (const r of results) {
      totalFetched += r.fetched;
      totalSaved   += r.saved;
      done++;
      process.stdout.write(`\r  ${done}/${companies.length} companies -- ${totalSaved} jobs saved`);
    }

    if (i + CONCURRENCY < companies.length) await sleep(500);
  }

  const elapsed = Math.round((Date.now() - started) / 1000);
  console.log('');
  console.log('');
  console.log(`crawl complete in ${elapsed}s`);
  console.log(`  companies: ${done}  fetched: ${totalFetched}  saved: ${totalSaved}`);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  try {
    await runCrawl();
  } catch (err) {
    console.error('crawl failed:', err.message);
  }

  cron.schedule('0 8,13,19 * * *', async () => {
    console.log('scheduled crawl triggered');
    try { await runCrawl(); } catch (err) { console.error(err.message); }
  });

  console.log('scheduler active -- next runs at 8am, 1pm, 7pm daily');
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});