# step 2 -- crawler

Reads companies.json, hits each ATS API, extracts structured data
with Gemini, and saves everything to PostgreSQL.


## files

  schema.sql       run this once to set up your database tables
  db.js            database connection and queries
  ats-fetchers.js  one fetcher per ATS (greenhouse, lever, ashby)
  ai-extractor.js  sends job description to Gemini, returns clean JSON
  dedup.js         hash-based duplicate detection
  crawler.js       main entry point, runs everything


## setup (do this once)

1. get your Gemini API key
   - go to aistudio.google.com
   - click "Get API key"
   - copy the key

2. add it to your .env file
   GEMINI_API_KEY=your-key-here

3. create the database tables
   psql -U postgres -d jobcrawler -f step2-crawl/schema.sql

4. confirm your .env has the database URL
   DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/jobcrawler


## run the crawler

  node step2-crawl/crawler.js

It will:
  - crawl all companies in companies.json immediately
  - then schedule itself to run again at 8am, 1pm, and 7pm daily
  - leave the terminal open (or use pm2) to keep the schedule running


## what you will see

  crawl started at 2026-04-12T10:00:00.000Z
  loaded 1243 companies from companies.json
  concurrency: 5  delay: 300ms  max jobs/company: 50

    1/1243 companies -- 0 jobs saved
    2/1243 companies -- 3 jobs saved
    ...
    1243/1243 companies -- 8420 jobs saved

  crawl complete in 847s
    companies crawled: 1243
    jobs fetched:      12840
    jobs saved:        8420


## gemini free tier limits

  15 requests per minute
  1,000,000 tokens per day
  ~1,000 tokens per job description
  = roughly 1,000 new jobs extracted per day for free

  the crawler respects this with CRAWL_DELAY_MS=300 between AI calls
  if you hit the rate limit it backs off automatically and retries


## environment variables

  DATABASE_URL          postgresql connection string (required)
  GEMINI_API_KEY        from aistudio.google.com (required)
  CRAWL_CONCURRENCY     companies to crawl at once (default 5)
  CRAWL_DELAY_MS        ms between AI extraction calls (default 300)
  MAX_JOBS_PER_COMPANY  cap per company to avoid noise (default 50)
