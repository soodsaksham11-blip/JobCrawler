/**
 * ai-extractor.js
 *
 * Calls the Gemini API directly using Node's built-in https module.
 * No openai library needed -- avoids the OPENAI_API_KEY confusion entirely.
 *
 * Free tier: gemini-1.5-flash -- 15 requests/min, 1M tokens/day
 */

const https  = require('https');
const path   = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const MODEL          = 'gemini-1.5-flash';
const RATE_LIMIT_BACKOFF = 5000;
const MAX_RETRIES        = 3;

if (!GEMINI_API_KEY) {
  throw new Error('GEMINI_API_KEY is missing from your .env file');
}

const SYSTEM_PROMPT = `You are a job posting parser. Extract structured information from job descriptions.
Return ONLY a valid JSON object with these exact fields. Use null for any field you cannot determine.

{
  "seniority":       "intern" | "junior" | "mid" | "senior" | "staff" | "principal" | "manager" | null,
  "specialty":       "frontend" | "backend" | "fullstack" | "ml" | "data" | "devops" | "mobile" | "security" | "embedded" | "other" | null,
  "tech_stack":      ["array", "of", "technologies"],
  "salary_min":      number or null,
  "salary_max":      number or null,
  "remote":          "remote" | "hybrid" | "onsite" | null,
  "yoe_min":         number or null,
  "visa_sponsored":  true | false,
  "canada_eligible": true | false
}

Rules:
- tech_stack: list languages, frameworks, tools, cloud platforms mentioned
- canada_eligible: true if job is in Canada, or fully remote with no country restriction
- visa_sponsored: true only if explicitly stated
- Return ONLY the JSON object, no markdown, no backticks, no explanation`;


// ---------------------------------------------------------------------------
// Raw HTTPS call to Gemini
// ---------------------------------------------------------------------------

function callGemini(prompt) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      contents: [
        {
          parts: [{ text: SYSTEM_PROMPT + '\n\nParse this job posting:\n\n' + prompt }]
        }
      ],
      generationConfig: {
        temperature:     0,
        maxOutputTokens: 500,
      },
    });

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${GEMINI_API_KEY}`;
    const urlObj = new URL(url);

    const options = {
      hostname: urlObj.hostname,
      path:     urlObj.pathname + urlObj.search,
      method:   'POST',
      headers:  {
        'Content-Type':   'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end',  ()  => resolve({ status: res.statusCode, body: data }));
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}


// ---------------------------------------------------------------------------
// Extract with retry on rate limit
// ---------------------------------------------------------------------------

async function extractWithAI(rawText, attempt = 1) {
  try {
    const text = (rawText || '').slice(0, 3000);

    if (!text.trim()) return defaultExtraction();

    const res = await callGemini(text);

    // rate limited
    if (res.status === 429) {
      if (attempt <= MAX_RETRIES) {
        await sleep(RATE_LIMIT_BACKOFF * attempt);
        return extractWithAI(rawText, attempt + 1);
      }
      return defaultExtraction();
    }

    if (res.status !== 200) {
      console.error(`    gemini returned ${res.status}`);
      return defaultExtraction();
    }

    let parsed;
    try { parsed = JSON.parse(res.body); } catch { return defaultExtraction(); }

    // Gemini response structure
    const content = parsed?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    return parseExtraction(content);

  } catch (err) {
    console.error(`    ai extraction error: ${err.message}`);
    return defaultExtraction();
  }
}


// ---------------------------------------------------------------------------
// Parse the text response into a clean object
// ---------------------------------------------------------------------------

function parseExtraction(raw) {
  try {
    const cleaned = raw
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i,    '')
      .replace(/```$/i,       '')
      .trim();

    const obj = JSON.parse(cleaned);

    return {
      seniority:       sanitizeEnum(obj.seniority,  ['intern','junior','mid','senior','staff','principal','manager']),
      specialty:       sanitizeEnum(obj.specialty,  ['frontend','backend','fullstack','ml','data','devops','mobile','security','embedded','other']),
      tech_stack:      Array.isArray(obj.tech_stack) ? obj.tech_stack.slice(0, 20) : [],
      salary_min:      toInt(obj.salary_min),
      salary_max:      toInt(obj.salary_max),
      remote:          sanitizeEnum(obj.remote,     ['remote','hybrid','onsite']),
      yoe_min:         toInt(obj.yoe_min),
      visa_sponsored:  Boolean(obj.visa_sponsored),
      canada_eligible: Boolean(obj.canada_eligible),
    };
  } catch {
    return defaultExtraction();
  }
}

function defaultExtraction() {
  return {
    seniority:       null,
    specialty:       null,
    tech_stack:      [],
    salary_min:      null,
    salary_max:      null,
    remote:          null,
    yoe_min:         null,
    visa_sponsored:  false,
    canada_eligible: false,
  };
}

function sanitizeEnum(value, allowed) {
  if (typeof value === 'string' && allowed.includes(value.toLowerCase())) {
    return value.toLowerCase();
  }
  return null;
}

function toInt(value) {
  const n = parseInt(value, 10);
  return isNaN(n) ? null : n;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

module.exports = { extractWithAI };