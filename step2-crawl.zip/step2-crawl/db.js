/**
 * db.js
 *
 * PostgreSQL connection pool and all database queries.
 */

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

pool.on('error', (err) => {
  console.error('pg pool error:', err.message);
});

async function upsertCompany(company) {
  const sql = `
    INSERT INTO companies
      (slug, name, ats, jobs_api, board_url, verified, active, discovered_at, source)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    ON CONFLICT (slug, ats) DO UPDATE SET
      name      = EXCLUDED.name,
      jobs_api  = EXCLUDED.jobs_api,
      board_url = EXCLUDED.board_url,
      active    = EXCLUDED.active
    RETURNING id
  `;
  const res = await pool.query(sql, [
    company.slug,
    company.name,
    company.ats,
    company.jobs_api     || null,
    company.board_url    || null,
    company.verified     || false,
    company.active       !== false,
    company.discovered_at || new Date().toISOString(),
    company.source       || null,
  ]);
  return res.rows[0].id;
}

async function markCompanyCrawled(slug, ats) {
  await pool.query(
    'UPDATE companies SET last_crawled = NOW() WHERE slug = $1 AND ats = $2',
    [slug, ats]
  );
}

async function jobExists(externalId, ats) {
  const res = await pool.query(
    'SELECT id FROM jobs WHERE external_id = $1 AND ats = $2',
    [externalId, ats]
  );
  return res.rows.length > 0;
}

async function hashExists(hash) {
  const res = await pool.query(
    'SELECT id FROM jobs WHERE content_hash = $1',
    [hash]
  );
  return res.rows.length > 0;
}

async function insertJob(job) {
  const sql = `
    INSERT INTO jobs (
      external_id, company_slug, company_name, ats,
      title, location, apply_url, date_posted,
      seniority, specialty, tech_stack,
      salary_min, salary_max, remote, yoe_min,
      visa_sponsored, canada_eligible,
      content_hash, raw_description
    ) VALUES (
      $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19
    )
    ON CONFLICT (external_id, ats) DO UPDATE SET
      last_seen  = NOW(),
      is_active  = TRUE,
      title      = EXCLUDED.title,
      location   = EXCLUDED.location,
      seniority  = EXCLUDED.seniority,
      tech_stack = EXCLUDED.tech_stack,
      salary_min = EXCLUDED.salary_min,
      salary_max = EXCLUDED.salary_max,
      remote     = EXCLUDED.remote
  `;
  await pool.query(sql, [
    job.external_id,
    job.company_slug,
    job.company_name,
    job.ats,
    job.title,
    job.location        || null,
    job.apply_url       || null,
    job.date_posted     || null,
    job.seniority       || null,
    job.specialty       || null,
    job.tech_stack      || [],
    job.salary_min      || null,
    job.salary_max      || null,
    job.remote          || null,
    job.yoe_min         || null,
    job.visa_sponsored  || false,
    job.canada_eligible || false,
    job.content_hash    || null,
    job.raw_description || null,
  ]);
}

async function markJobsInactive(companySlug, ats, activeExternalIds) {
  if (activeExternalIds.length === 0) return;
  await pool.query(
    `UPDATE jobs SET is_active = FALSE
     WHERE company_slug = $1 AND ats = $2
       AND external_id != ALL($3) AND is_active = TRUE`,
    [companySlug, ats, activeExternalIds]
  );
}

async function end() {
  await pool.end();
}

module.exports = {
  upsertCompany,
  markCompanyCrawled,
  jobExists,
  hashExists,
  insertJob,
  markJobsInactive,
  end,
};