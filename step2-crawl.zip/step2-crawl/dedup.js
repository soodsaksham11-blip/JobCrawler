/**
 * dedup.js
 *
 * Simple hash-based deduplication.
 * We hash the job title + company + location to catch obvious reposts.
 *
 * pgvector-based semantic deduplication can be layered on top later
 * once the crawler is working end to end.
 */

const crypto = require('crypto');

/**
 * Returns a short hash that identifies a job.
 * Two jobs with the same title at the same company in the same location
 * will produce the same hash and be treated as duplicates.
 */
function hashJob(title, companySlug, location) {
  const raw = [
    (title    || '').toLowerCase().trim(),
    (companySlug || '').toLowerCase().trim(),
    (location || '').toLowerCase().trim(),
  ].join('||');

  return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 16);
}

module.exports = { hashJob };
