/**
 * ats-fetchers.js
 *
 * One function per ATS type. Each returns an array of raw job objects
 * in a normalised shape:
 *
 *   {
 *     external_id:     string   -- unique ID from the ATS
 *     title:           string
 *     location:        string
 *     apply_url:       string
 *     date_posted:     string (ISO)
 *     raw_description: string   -- plain text for AI extraction
 *   }
 */

const https = require('https');

function get(url) {
  return new Promise((resolve) => {
    const opts = { headers: { 'User-Agent': 'JobCrawlerBot/1.0' } };
    https.get(url, opts, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return get(res.headers.location).then(resolve);
      }
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end',  ()  => resolve({ status: res.statusCode, body }));
    }).on('error', () => resolve({ status: 0, body: '' }));
  });
}

function stripHtml(html) {
  return (html || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g,  '&')
    .replace(/&lt;/g,   '<')
    .replace(/&gt;/g,   '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}


// ---------------------------------------------------------------------------
// Greenhouse
// ---------------------------------------------------------------------------

async function fetchGreenhouse(company) {
  const url = company.jobs_api ||
    `https://boards-api.greenhouse.io/v1/boards/${company.slug}/jobs?content=true`;

  const res = await get(url);
  if (res.status !== 200) return [];

  let data;
  try { data = JSON.parse(res.body); } catch { return []; }

  const raw = data.jobs || [];

  return raw.map((j) => ({
    external_id:     String(j.id),
    title:           j.title || '',
    location:        j.location?.name || '',
    apply_url:       j.absolute_url || '',
    date_posted:     j.updated_at || null,
    raw_description: stripHtml(j.content || ''),
  }));
}


// ---------------------------------------------------------------------------
// Lever
// ---------------------------------------------------------------------------

async function fetchLever(company) {
  const url = company.jobs_api ||
    `https://api.lever.co/v0/postings/${company.slug}?mode=json`;

  const res = await get(url);
  if (res.status !== 200) return [];

  let data;
  try { data = JSON.parse(res.body); } catch { return []; }

  const raw = Array.isArray(data) ? data : [];

  return raw.map((j) => ({
    external_id:     j.id || '',
    title:           j.text || '',
    location:        j.categories?.location || j.country || '',
    apply_url:       j.hostedUrl || j.applyUrl || '',
    date_posted:     j.createdAt ? new Date(j.createdAt).toISOString() : null,
    raw_description: stripHtml(
      (j.descriptionPlain || '') + ' ' +
      (j.additionalPlain  || '') + ' ' +
      (j.lists || []).map((l) => l.content).join(' ')
    ),
  }));
}


// ---------------------------------------------------------------------------
// Ashby
// ---------------------------------------------------------------------------

async function fetchAshby(company) {
  const url = company.jobs_api ||
    `https://api.ashbyhq.com/posting-api/job-board/${company.slug}`;

  const res = await get(url);
  if (res.status !== 200) return [];

  let data;
  try { data = JSON.parse(res.body); } catch { return []; }

  const raw = data.jobPostings || data.jobs || [];

  return raw.map((j) => ({
    external_id:     j.id || j.jobId || '',
    title:           j.title || '',
    location:        j.locationName || j.location || '',
    apply_url:       j.jobUrl || j.applyUrl || '',
    date_posted:     j.publishedDate || j.createdAt || null,
    raw_description: stripHtml(j.descriptionHtml || j.description || ''),
  }));
}


// ---------------------------------------------------------------------------
// Router -- picks the right fetcher based on ats field
// ---------------------------------------------------------------------------

async function fetchJobs(company) {
  switch (company.ats) {
    case 'greenhouse': return fetchGreenhouse(company);
    case 'lever':      return fetchLever(company);
    case 'ashby':      return fetchAshby(company);
    default:
      console.log(`    unknown ats type: ${company.ats}`);
      return [];
  }
}

module.exports = { fetchJobs };
