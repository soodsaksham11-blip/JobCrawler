-- schema.sql
-- Run this once to set up your database before running the crawler.
--
-- psql -U postgres -d jobcrawler -f step2-crawl/schema.sql

CREATE TABLE IF NOT EXISTS companies (
  id            SERIAL PRIMARY KEY,
  slug          TEXT NOT NULL,
  name          TEXT NOT NULL,
  ats           TEXT NOT NULL,
  jobs_api      TEXT,
  board_url     TEXT,
  verified      BOOLEAN DEFAULT FALSE,
  active        BOOLEAN DEFAULT TRUE,
  discovered_at TIMESTAMPTZ,
  source        TEXT,
  last_crawled  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(slug, ats)
);

CREATE TABLE IF NOT EXISTS jobs (
  id              SERIAL PRIMARY KEY,
  external_id     TEXT,
  company_slug    TEXT NOT NULL,
  company_name    TEXT NOT NULL,
  ats             TEXT NOT NULL,

  -- raw fields from ATS
  title           TEXT NOT NULL,
  location        TEXT,
  apply_url       TEXT,
  date_posted     TIMESTAMPTZ,
  last_seen       TIMESTAMPTZ DEFAULT NOW(),

  -- AI extracted fields
  seniority       TEXT,
  specialty       TEXT,
  tech_stack      TEXT[],
  salary_min      INT,
  salary_max      INT,
  remote          TEXT,
  yoe_min         INT,
  visa_sponsored  BOOLEAN,
  canada_eligible BOOLEAN,

  -- deduplication (simple hash until pgvector is set up)
  content_hash    TEXT,

  -- metadata
  raw_description TEXT,
  is_active       BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),

  UNIQUE(external_id, ats)
);

-- indexes for fast filtering
CREATE INDEX IF NOT EXISTS idx_jobs_company    ON jobs(company_slug);
CREATE INDEX IF NOT EXISTS idx_jobs_remote     ON jobs(remote);
CREATE INDEX IF NOT EXISTS idx_jobs_seniority  ON jobs(seniority);
CREATE INDEX IF NOT EXISTS idx_jobs_posted     ON jobs(date_posted DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_hash       ON jobs(content_hash);
CREATE INDEX IF NOT EXISTS idx_jobs_active     ON jobs(is_active) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_jobs_stack      ON jobs USING GIN(tech_stack);

