/**
 * merge-companies.js
 *
 * Merges greenhouse-companies.json, lever-companies.json, and
 * ashby-companies.json into a single companies.json file at the
 * project root. Also includes a hardcoded list of big tech companies
 * that use Workday or fully custom career pages.
 *
 * Run this after all three discovery scripts have finished:
 *
 *   node discover-greenhouse.js
 *   node discover-lever.js
 *   node discover-ashby.js
 *   node merge-companies.js
 *
 * Output: ../companies.json
 */

const fs   = require('fs');
const path = require('path');


// ---------------------------------------------------------------------------
// Load helpers
// ---------------------------------------------------------------------------

function load(filename) {
  const filepath = path.join(__dirname, filename);

  if (!fs.existsSync(filepath)) {
    console.log(`  ${filename} not found, skipping`);
    return [];
  }

  const data = JSON.parse(fs.readFileSync(filepath, 'utf-8'));
  console.log(`  ${filename}: ${data.length} companies`);
  return data;
}


// ---------------------------------------------------------------------------
// Big tech + companies with Workday or custom career pages
//
// These cannot be discovered from a sitemap so we hardcode them.
// The crawler will handle these differently (puppeteer or custom fetch).
// ---------------------------------------------------------------------------

const BIG_TECH = [
  {
    slug:         'google',
    name:         'Google',
    ats:          'custom',
    jobs_api:     null,
    board_url:    'https://careers.google.com/jobs/results/?category=SOFTWARE_ENGINEERING',
    crawler_type: 'puppeteer',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         'meta',
    name:         'Meta',
    ats:          'custom',
    jobs_api:     'https://www.metacareers.com/graphql',
    board_url:    'https://www.metacareers.com/jobs',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         'apple',
    name:         'Apple',
    ats:          'custom',
    jobs_api:     'https://jobs.apple.com/api/role/search',
    board_url:    'https://jobs.apple.com/en-us/search?team=software-and-services',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         'amazon',
    name:         'Amazon',
    ats:          'custom',
    jobs_api:     'https://www.amazon.jobs/en/search.json?category=software-development',
    board_url:    'https://www.amazon.jobs/en/job_categories/software-development',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         'microsoft',
    name:         'Microsoft',
    ats:          'custom',
    jobs_api:     'https://jobs.careers.microsoft.com/global/en/search',
    board_url:    'https://jobs.careers.microsoft.com',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },

  // Canadian big tech -- verified Greenhouse/Lever slugs
  {
    slug:         'shopify',
    name:         'Shopify',
    ats:          'greenhouse',
    jobs_api:     'https://boards-api.greenhouse.io/v1/boards/shopify/jobs?content=true',
    board_url:    'https://boards.greenhouse.io/shopify',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         'wealthsimple',
    name:         'Wealthsimple',
    ats:          'greenhouse',
    jobs_api:     'https://boards-api.greenhouse.io/v1/boards/wealthsimple/jobs?content=true',
    board_url:    'https://boards.greenhouse.io/wealthsimple',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         '1password',
    name:         '1Password',
    ats:          'ashby',
    jobs_api:     'https://api.ashbyhq.com/posting-api/job-board/1password',
    board_url:    'https://jobs.ashbyhq.com/1password',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         'cohere',
    name:         'Cohere',
    ats:          'greenhouse',
    jobs_api:     'https://boards-api.greenhouse.io/v1/boards/cohere/jobs?content=true',
    board_url:    'https://boards.greenhouse.io/cohere',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         'openai',
    name:         'OpenAI',
    ats:          'greenhouse',
    jobs_api:     'https://boards-api.greenhouse.io/v1/boards/openai/jobs?content=true',
    board_url:    'https://boards.greenhouse.io/openai',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
  {
    slug:         'anthropic',
    name:         'Anthropic',
    ats:          'lever',
    jobs_api:     'https://api.lever.co/v0/postings/anthropic?mode=json',
    board_url:    'https://jobs.lever.co/anthropic',
    crawler_type: 'api',
    verified:     true,
    active:       true,
    discovered_at: new Date().toISOString(),
    source:       'manual',
  },
];


// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

function main() {
  console.log('loading source files...');
  console.log('');

  const greenhouse = load('greenhouse-companies.json');
  const lever      = load('lever-companies.json');
  const ashby      = load('ashby-companies.json');

  console.log(`  big-tech (hardcoded): ${BIG_TECH.length} companies`);
  console.log('');

  const all = [...greenhouse, ...lever, ...ashby, ...BIG_TECH];

  console.log(`total before dedup: ${all.length}`);

  // deduplicate on ats + slug
  // the same slug can legitimately appear on two different ATS platforms
  // (rare but it happens when companies migrate) so we key on both
  const seen    = new Set();
  const deduped = all.filter((c) => {
    const key = `${c.ats}:${c.slug}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  console.log(`total after dedup:  ${deduped.length}`);
  console.log('');

  // breakdown by ATS
  const byATS = deduped.reduce((acc, c) => {
    acc[c.ats] = (acc[c.ats] || 0) + 1;
    return acc;
  }, {});

  console.log('breakdown by ATS:');
  Object.entries(byATS)
    .sort((a, b) => b[1] - a[1])
    .forEach(([ats, count]) => {
      const label = ats.padEnd(16);
      console.log(`  ${label} ${count}`);
    });

  console.log('');

  const out = path.join(__dirname, '..', 'companies.json');
  fs.writeFileSync(out, JSON.stringify(deduped, null, 2));

  console.log(`wrote companies.json (${deduped.length} total)`);
  console.log('');
  console.log('next: node step2-crawl/crawler.js');
}

main();
