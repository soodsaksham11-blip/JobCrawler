/**
 * discover-ashby.js
 *
 * Pulls every company slug from Ashby's public sitemap and writes
 * them to ashby-companies.json.
 *
 * Ashby is smaller than Greenhouse or Lever (~1,500 companies) but
 * worth targeting because a lot of the best-funded startups migrated
 * to it -- Linear, Vercel, Cohere, Cursor, Perplexity, etc.
 *
 * Ashby slugs can contain dots (e.g. "company.engineering") which is
 * slightly different from the other two. We handle that below.
 *
 * Run: node discover-ashby.js
 */

const https = require('https');
const fs    = require('fs');
const path  = require('path');


// ---------------------------------------------------------------------------
// HTTP helper
// ---------------------------------------------------------------------------

function get(url) {
  return new Promise((resolve, reject) => {
    const options = {
      headers: { 'User-Agent': 'StackHireBot/1.0' },
    };

    https.get(url, options, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return get(res.headers.location).then(resolve).catch(reject);
      }

      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end',  ()      => { resolve({ status: res.statusCode, body }); });
    }).on('error', reject);
  });
}


// ---------------------------------------------------------------------------
// Slug helpers
// ---------------------------------------------------------------------------

function slugToName(slug) {
  return slug
    .replace(/[.\-_]/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
}

function buildRecord(slug) {
  return {
    slug,
    name:          slugToName(slug),
    ats:           'ashby',
    jobs_api:      `https://api.ashbyhq.com/posting-api/job-board/${slug}`,
    board_url:     `https://jobs.ashbyhq.com/${slug}`,
    verified:      false,
    active:        true,
    discovered_at: new Date().toISOString(),
    source:        'ashby_sitemap',
  };
}


// ---------------------------------------------------------------------------
// Discovery
// ---------------------------------------------------------------------------

async function discoverFromSitemap() {
  console.log('fetching ashby sitemap...');

  const res = await get('https://jobs.ashbyhq.com/sitemap.xml');

  if (res.status !== 200) {
    throw new Error(`sitemap returned ${res.status}`);
  }

  // Ashby job URLs look like: https://jobs.ashbyhq.com/linear/abc-123
  // We want the slug between the domain and the job ID.
  // Some slugs have dots: jobs.ashbyhq.com/company.engineering/...
  const matches = [...res.body.matchAll(/jobs\.ashbyhq\.com\/([a-zA-Z0-9_.-]+)/g)];

  const slugs = [...new Set(
    matches
      .map((m) => m[1].toLowerCase())
      .filter((s) => s.length > 1 && !s.includes('sitemap'))
  )];

  console.log(`found ${slugs.length} slugs in sitemap`);
  return slugs;
}

// These are companies we know are on Ashby but might not appear in the
// sitemap depending on how Ashby structures their XML at crawl time.
function knownSlugs() {
  return [
    // dev tools and infra
    'linear', 'vercel', 'railway', 'render', 'planetscale',
    'neon', 'supabase', 'convex', 'grafana', 'posthog',
    'sentry', 'incident-io', 'deno',

    // AI
    'cohere', 'runway', 'elevenlabs', 'perplexity',
    'together', 'modal', 'replicate', 'cursor',

    // fintech
    'mercury', 'rho', 'puzzle', 'pilot', 'column', 'lithic',

    // Canadian tech
    '1password', 'clio', 'properly', 'koho', 'clearco',

    // other
    'loom', 'retool', 'webflow', 'framer', 'stytch',
    'clerk', 'workos', 'dbt-labs', 'hex', 'metabase',
  ];
}


// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  console.log('starting ashby company discovery');
  console.log('');

  let sitemap = [];

  try {
    sitemap = await discoverFromSitemap();
  } catch (err) {
    console.log(`sitemap failed: ${err.message}`);
    console.log('continuing with known slug list only');
  }

  const all = [...new Set([...sitemap, ...knownSlugs()])];

  const companies = all
    .filter((s) => s.length > 1)
    .map(buildRecord);

  const out = path.join(__dirname, 'ashby-companies.json');
  fs.writeFileSync(out, JSON.stringify(companies, null, 2));

  console.log(`wrote ${companies.length} companies to ashby-companies.json`);
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
