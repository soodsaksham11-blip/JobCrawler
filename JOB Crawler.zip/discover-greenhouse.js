/**
 * discover-greenhouse.js
 *
 * Pulls every company slug from Greenhouse's public sitemap and writes
 * them to greenhouse-companies.json.
 *
 * Greenhouse publishes a sitemap of all their job boards because it is
 * in their interest for companies to be discoverable. No API key, no
 * auth, no rate limiting on the sitemap itself.
 *
 * Run: node discover-greenhouse.js
 */

const https = require('https');
const fs    = require('fs');
const path  = require('path');


// ---------------------------------------------------------------------------
// HTTP helper
// ---------------------------------------------------------------------------

function get(url) {
  return new Promise((resolve, reject) => {
    const options = {
      headers: { 'User-Agent': 'StackHireBot/1.0' },
    };

    https.get(url, options, (res) => {
      // follow one level of redirect
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return get(res.headers.location).then(resolve).catch(reject);
      }

      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end',  ()      => { resolve({ status: res.statusCode, body }); });
    }).on('error', reject);
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}


// ---------------------------------------------------------------------------
// Slug helpers
// ---------------------------------------------------------------------------

// Turns "shopify-engineering" into "Shopify Engineering"
function slugToName(slug) {
  return slug
    .replace(/[-_]/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function buildRecord(slug) {
  return {
    slug,
    name:           slugToName(slug),
    ats:            'greenhouse',
    jobs_api:       `https://boards-api.greenhouse.io/v1/boards/${slug}/jobs?content=true`,
    board_url:      `https://boards.greenhouse.io/${slug}`,
    verified:       false,
    active:         true,
    discovered_at:  new Date().toISOString(),
    source:         'greenhouse_sitemap',
  };
}


// ---------------------------------------------------------------------------
// Discovery
// ---------------------------------------------------------------------------

async function discoverFromSitemap() {
  console.log('fetching greenhouse sitemap...');

  const res = await get('https://boards.greenhouse.io/sitemap.xml');

  if (res.status !== 200) {
    throw new Error(`sitemap returned ${res.status}`);
  }

  console.log(`sitemap received (${Math.round(res.body.length / 1024)} KB)`);

  // every company board appears as:
  //   <loc>https://boards.greenhouse.io/shopify</loc>
  const matches = [...res.body.matchAll(/boards\.greenhouse\.io\/([a-zA-Z0-9_-]+)/g)];

  const SKIP = new Set(['sitemap', 'embed', 'api', 'robots', 'humans', 'favicon']);

  const slugs = [...new Set(
    matches
      .map((m) => m[1].toLowerCase())
      .filter((s) => s.length > 1 && !SKIP.has(s))
  )];

  console.log(`found ${slugs.length} slugs in sitemap`);
  return slugs;
}

function fallbackSlugs() {
  // used when the sitemap fetch fails
  return [
    'shopify', 'stripe', 'airbnb', 'lyft', 'pinterest', 'dropbox',
    'zendesk', 'hubspot', 'twilio', 'sendgrid', 'segment', 'mixpanel',
    'figma', 'notion', 'airtable', 'asana', 'gusto', 'rippling',
    'brex', 'ramp', 'mercury', 'carta', 'plaid', 'coinbase', 'kraken',
    'instacart', 'doordash', 'datadog', 'newrelic', 'splunk', 'elastic',
    'mongodb', 'confluent', 'databricks', 'snowflake', 'fivetran',
    'hashicorp', 'circleci', 'gitlab', 'atlassian', 'intercom',
    'cohere', '1password', 'wealthsimple', 'hootsuite', 'lightspeed',
    'benevity', 'clio', 'd2l', 'vidyard', 'openai',
  ];
}


// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  let slugs;

  try {
    slugs = await discoverFromSitemap();
  } catch (err) {
    console.log(`sitemap fetch failed: ${err.message}`);
    console.log('falling back to known slug list');
    slugs = fallbackSlugs();
  }

  const companies = slugs.map(buildRecord);

  const out = path.join(__dirname, 'greenhouse-companies.json');
  fs.writeFileSync(out, JSON.stringify(companies, null, 2));

  console.log(`wrote ${companies.length} companies to greenhouse-companies.json`);
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
