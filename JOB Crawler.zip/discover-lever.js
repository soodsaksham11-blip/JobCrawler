/**
 * discover-lever.js
 *
 * Pulls every company slug from Lever's public sitemaps and writes
 * them to lever-companies.json.
 *
 * Lever splits their sitemap by letter: sitemap-a.xml, sitemap-b.xml ...
 * sitemap-z.xml. Each file contains URLs for every job posting under
 * that letter, from which we extract the company slug.
 *
 * Run: node discover-lever.js
 */

const https = require('https');
const fs    = require('fs');
const path  = require('path');


// ---------------------------------------------------------------------------
// HTTP helper
// ---------------------------------------------------------------------------

function get(url) {
  return new Promise((resolve, reject) => {
    const options = {
      headers: { 'User-Agent': 'StackHireBot/1.0' },
    };

    https.get(url, options, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return get(res.headers.location).then(resolve).catch(reject);
      }

      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end',  ()      => { resolve({ status: res.statusCode, body }); });
    }).on('error', reject);
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}


// ---------------------------------------------------------------------------
// Slug helpers
// ---------------------------------------------------------------------------

function slugToName(slug) {
  return slug
    .replace(/[-_]/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function buildRecord(slug) {
  return {
    slug,
    name:          slugToName(slug),
    ats:           'lever',
    // Lever exposes a clean public JSON API for every company board.
    // No authentication required.
    jobs_api:      `https://api.lever.co/v0/postings/${slug}?mode=json`,
    board_url:     `https://jobs.lever.co/${slug}`,
    verified:      false,
    active:        true,
    discovered_at: new Date().toISOString(),
    source:        'lever_sitemap',
  };
}


// ---------------------------------------------------------------------------
// Discovery
// ---------------------------------------------------------------------------

async function discoverFromSitemaps() {
  const alphabet = 'abcdefghijklmnopqrstuvwxyz'.split('');
  const slugs    = new Set();
  let   failed   = 0;

  for (const letter of alphabet) {
    const url = `https://jobs.lever.co/sitemap-${letter}.xml`;

    try {
      process.stdout.write(`  sitemap-${letter}.xml ... `);
      const res = await get(url);

      if (res.status === 200) {
        // job posting URLs look like: https://jobs.lever.co/stripe/abc-def-123
        // we only want the company slug (second path segment)
        const matches = [...res.body.matchAll(/jobs\.lever\.co\/([a-zA-Z0-9_-]+)\//g)];
        let count = 0;

        for (const m of matches) {
          slugs.add(m[1].toLowerCase());
          count++;
        }

        console.log(`${count} URLs`);
      } else {
        console.log(`${res.status}`);
      }
    } catch (err) {
      console.log(`error: ${err.message}`);
      failed++;
    }

    // small delay between requests
    await sleep(150);
  }

  if (failed === alphabet.length) {
    throw new Error('all sitemap requests failed');
  }

  return [...slugs];
}

function knownSlugs() {
  return [
    'netflix', 'uber', 'square', 'block', 'affirm', 'faire',
    'benchling', 'scale', 'openai', 'anthropic', 'waymo',
    'aurora', 'rivian', 'canva', 'atlassian', 'afterpay',
    'xero', 'wealthsimple', 'freshbooks', 'geotab',
    'benevity', 'absorb', 'vendasta',
  ];
}


// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  console.log('starting lever company discovery');
  console.log('');

  let slugs;

  try {
    slugs = await discoverFromSitemaps();
  } catch (err) {
    console.log(`sitemap discovery failed: ${err.message}`);
    console.log('falling back to known slug list');
    slugs = knownSlugs();
  }

  // merge in known slugs in case the sitemap missed any
  const all = [...new Set([...slugs, ...knownSlugs()])];

  const companies = all
    .filter((s) => s.length > 1)
    .map(buildRecord);

  const out = path.join(__dirname, 'lever-companies.json');
  fs.writeFileSync(out, JSON.stringify(companies, null, 2));

  console.log('');
  console.log(`wrote ${companies.length} companies to lever-companies.json`);
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
