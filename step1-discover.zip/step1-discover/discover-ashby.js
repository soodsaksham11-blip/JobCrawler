/**
 * discover-ashby.js
 *
 * Ashby sitemap returns minimal data. We use:
 *   1. scrape Google for site:jobs.ashbyhq.com results
 *   2. scrape Bing for the same
 *   3. seed list of ~500 known Ashby companies
 * Then verify each against the live Ashby API.
 *
 * Run: node step1-discover/discover-ashby.js
 */

const https = require('https');
const fs    = require('fs');
const path  = require('path');

function get(url) {
  return new Promise((resolve) => {
    https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      }
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return get(res.headers.location).then(resolve);
      }
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end',  ()  => resolve({ status: res.statusCode, body }));
    }).on('error', () => resolve({ status: 0, body: '' }));
  });
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

function extractAshbySlugs(html) {
  const slugs = new Set();
  for (const m of html.matchAll(/jobs\.ashbyhq\.com\/([a-zA-Z0-9_.-]+)/g)) {
    const s = m[1].toLowerCase().replace(/\/$/, '');
    if (s.length > 1 && !s.includes('sitemap')) slugs.add(s);
  }
  return [...slugs];
}

async function fromGoogle() {
  const found = new Set();
  const queries = [
    'site:jobs.ashbyhq.com software engineer',
    'site:jobs.ashbyhq.com backend engineer',
    'site:jobs.ashbyhq.com frontend engineer',
    'site:jobs.ashbyhq.com machine learning',
    'site:jobs.ashbyhq.com data engineer',
    'site:jobs.ashbyhq.com devops',
    'site:jobs.ashbyhq.com senior engineer',
    'site:jobs.ashbyhq.com staff engineer',
    'site:jobs.ashbyhq.com engineering manager',
    'site:jobs.ashbyhq.com product manager',
    'site:jobs.ashbyhq.com remote',
    'site:jobs.ashbyhq.com canada',
    'site:jobs.ashbyhq.com new york',
    'site:jobs.ashbyhq.com san francisco',
    'site:jobs.ashbyhq.com seattle',
    'site:jobs.ashbyhq.com fullstack',
    'site:jobs.ashbyhq.com infrastructure',
    'site:jobs.ashbyhq.com security',
    'site:jobs.ashbyhq.com mobile',
    'site:jobs.ashbyhq.com ai startup',
  ];

  console.log(`  running ${queries.length} Google queries...`);

  for (let i = 0; i < queries.length; i++) {
    process.stdout.write(`\r  query ${i + 1}/${queries.length} -- ${found.size} slugs so far`);

    for (const start of [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]) {
      const url = `https://www.google.com/search?q=${encodeURIComponent(queries[i])}&num=10&start=${start}`;
      const res = await get(url);
      if (res.status === 200) {
        for (const s of extractAshbySlugs(res.body)) found.add(s);
      } else if (res.status === 429 || res.body.includes('unusual traffic')) {
        await sleep(5000);
        break;
      }
      await sleep(700);
    }
    await sleep(1200);
  }

  process.stdout.write('\n');
  console.log(`  found ${found.size} slugs from Google`);
  return [...found];
}

async function fromBing() {
  const found = new Set();
  const queries = [
    'site:jobs.ashbyhq.com engineer',
    'site:jobs.ashbyhq.com software',
    'site:jobs.ashbyhq.com developer',
    'site:jobs.ashbyhq.com remote',
    'site:jobs.ashbyhq.com startup',
    'site:jobs.ashbyhq.com senior',
    'site:jobs.ashbyhq.com product',
    'site:jobs.ashbyhq.com ai',
  ];

  console.log(`  running ${queries.length} Bing queries...`);

  for (let i = 0; i < queries.length; i++) {
    process.stdout.write(`\r  query ${i + 1}/${queries.length} -- ${found.size} slugs so far`);

    for (const first of [1, 11, 21, 31, 41, 51]) {
      const url = `https://www.bing.com/search?q=${encodeURIComponent(queries[i])}&count=10&first=${first}`;
      const res = await get(url);
      if (res.status === 200) {
        for (const s of extractAshbySlugs(res.body)) found.add(s);
      }
      await sleep(500);
    }
    await sleep(900);
  }

  process.stdout.write('\n');
  console.log(`  found ${found.size} slugs from Bing`);
  return [...found];
}

const SEED_SLUGS = [
  // dev tools and infra (Ashby's sweet spot)
  'linear', 'vercel', 'railway', 'render', 'fly', 'planetscale',
  'neon', 'supabase', 'xata', 'turso', 'convex', 'deno', 'bun',
  'grafana', 'posthog', 'highlight', 'sentry', 'incident-io',
  'rootly', 'firehydrant', 'blameless', 'betterstack', 'checkly',
  'cypress', 'browserstack', 'lambdatest', 'sauce-labs', 'percy',
  'chromatic', 'applitools', 'testim', 'mabl', 'rainforest-qa',
  'sourcegraph', 'codacy', 'codecov', 'deepsource',
  'postman', 'insomnia', 'hoppscotch',
  'supabase', 'neon', 'planetscale', 'turso',
  'cockroachdb', 'yugabyte', 'singlestore', 'timescale',
  'redis', 'dragonflydb', 'momento',
  'confluent', 'redpanda', 'warpstream',
  'airbyte', 'fivetran', 'stitch', 'matillion',
  'pulumi', 'crossplane', 'upbound',
  'buildkite', 'semaphore-ci',
  'netlify', 'fastly', 'cloudflare-workers',
  'vultr', 'linode', 'digitalocean', 'hetzner',
  'civo', 'paperspace', 'lambda-labs', 'coreweave',
  'together', 'modal', 'replicate', 'banana', 'beam',
  // AI (very popular on Ashby)
  'cohere', 'perplexity', 'cursor', 'midjourney',
  'runway', 'elevenlabs', 'stability', 'pika',
  'humanloop', 'dust', 'fixie', 'adept', 'inflection',
  'imbue', 'character', 'krea', 'ideogram',
  'synthesia', 'heygen', 'd-id', 'deepbrain', 'elai',
  'murf', 'resemble', 'lovo', 'play-ht', 'speechify',
  'jasper', 'writer', 'copy-ai', 'typeface', 'coframe',
  'moveworks', 'glean', 'guru', 'tettra', 'nuclino',
  'vectara', 'pinecone', 'weaviate', 'qdrant', 'chroma',
  'marqo', 'zilliz', 'relevance-ai', 'turbopuffer', 'trieve',
  'nomic', 'voyage-ai', 'jina',
  'scale', 'labelbox', 'encord', 'v7-labs', 'roboflow',
  'darwin-ai', 'landing-ai', 'clarifai',
  'datarobot', 'h2o', 'dataiku',
  'weights-biases', 'neptune', 'comet', 'guild',
  'determined-ai', 'flyte', 'metaflow', 'zenml',
  'bentoml', 'seldon', 'modzy',
  // Canadian
  '1password', 'clio', 'properly', 'coconut', 'clutch',
  'koho', 'clearco', 'trulioo', 'thinkific', 'unbounce',
  'procurify', 'push-operations', 'dye-durham', 'bench',
  'jobber', 'humi', 'collage', 'swiftly', 'miovision',
  'coveo', 'dialogue', 'tulip-retail', 'ecobee', 'ritual',
  'nuvei', 'geotab', 'vidyard', 'd2l', 'freshbooks', 'lightspeed',
  // fintech
  'mercury', 'brex', 'ramp', 'rho', 'puzzle', 'pilot', 'column',
  'lithic', 'unit', 'synctera', 'increase', 'modern-treasury',
  'stripe', 'adyen', 'checkout', 'klarna', 'affirm', 'afterpay',
  'sezzle', 'zip', 'paidy', 'scalapay',
  'socure', 'alloy', 'sardine', 'sentilink', 'persona', 'veriff',
  'paxos', 'anchorage', 'bitgo', 'fireblocks',
  'robinhood', 'betterment', 'wealthfront', 'sofi',
  'dave', 'albert', 'brigit', 'current', 'lili', 'relay',
  'bluevine', 'ondeck', 'upgrade', 'upstart', 'earnest', 'stilt',
  // SaaS
  'rippling', 'lattice', 'leapsome', 'culture-amp', 'workramp',
  'seismic', 'highspot', 'mindtickle', 'showpad',
  'remote', 'deel', 'oyster', 'papaya-global', 'multiplier',
  'bamboohr', 'justworks', 'gusto',
  'pipedrive', 'close', 'outreach', 'salesloft', 'gong',
  'chorus', 'clari', 'boostup', 'avoma', 'grain',
  'fireflies', 'wingman', 'cresta',
  'hubspot', 'braze', 'iterable', 'klaviyo',
  'zendesk', 'intercom', 'freshdesk', 'gorgias', 'tidio', 'gladly',
  'yotpo', 'okendo', 'recharge', 'skio', 'loop',
  'shopify', 'bigcommerce', 'elastic-path', 'fabric', 'chord',
  'retool', 'webflow', 'framer', 'bubble', 'glideapps',
  'stytch', 'clerk', 'workos', 'permit',
  'notion', 'coda', 'clickup', 'height', 'shortcut',
  'productboard', 'aha', 'airfocus',
  'miro', 'figma', 'lucidchart', 'whimsical', 'mural', 'loom',
  // health
  'oscar', 'modernhealth', 'lyra-health', 'spring-health',
  'headway', 'alma', 'path', 'rula', 'grow-therapy',
  'sword-health', 'hinge-health', 'kaia',
  'omada', 'noom', 'calibrate', 'ro', 'hims', 'nurx',
  'maven', 'progyny', 'carrot', 'kindbody',
  'city-block', 'carbon-health', 'one-medical', 'forward',
  'accolade', 'transcarent',
  'flatiron', 'tempus', 'color', 'invitae', 'natera',
  'veeva', 'medidata',
  // ecommerce
  'faire', 'whatnot', 'depop', 'poshmark', 'thredup',
  'the-realreal', 'rebag', 'opendoor', 'compass', 'redfin',
  // data
  'dbt-labs', 'hex', 'mode', 'metabase', 'lightdash',
  'thoughtspot', 'sigma', 'atlan', 'alation', 'collibra',
  'amplitude', 'mixpanel', 'heap', 'fullstory', 'posthog',
  'segment', 'rudderstack', 'mparticle', 'tealium', 'census', 'hightouch',
  'starburst', 'dremio', 'trino',
  // security
  'wiz', 'orca', 'lacework', 'chainguard', 'snyk', 'semgrep',
  'crowdstrike', 'sentinelone', 'vectra', 'darktrace',
  'okta', 'ping', 'sailpoint', 'saviynt', 'cyberark', 'beyond-trust',
  // gaming
  'roblox', 'niantic', 'scopely', 'jam-city', 'rovio',
  'supercell', 'playrix', 'playtika', 'zynga', 'applovin',
  // media
  'substack', 'beehiiv', 'convertkit', 'ghost', 'medium', 'automattic',
  // climate
  'watershed', 'pachama', 'heirloom', 'twelve', 'remora',
  'sunrun', 'sunnova', 'nextracker', 'enphase',
  // proptech
  'procore', 'fieldwire', 'raken', 'housecall-pro', 'servicetitan',
  'thumbtack', 'taskrabbit', 'angi',
  // robotics and space
  'covariant', 'omnirobotic', 'robust-ai', 'agility-robotics',
  'figure', 'physical-intelligence', '1x-technologies', 'sanctuary-ai',
  'planet', 'spire', 'relativity-space', 'rocket-lab', 'astra',
  'anduril', 'shield-ai', 'rebellion-defense', 'primer', 'govini',
  // insurance
  'lemonade', 'root', 'hippo', 'coalition', 'corvus', 'cowbell', 'at-bay',
  // legal
  'ironclad', 'evisort', 'lexion', 'icertis', 'luminance',
  // edtech
  'coursera', 'udemy', 'duolingo', 'babbel', 'preply', 'outschool',
  // travel
  'airbnb', 'sonder', 'vacasa', 'hopper', 'turo', 'getaround',
  // social
  'discord', 'circle', 'mighty-networks', 'reddit', 'quora',
  // crypto
  'coinbase', 'kraken', 'gemini', 'anchorage', 'bitgo', 'fireblocks',
  'alchemy', 'opensea', 'dapper-labs', 'immutable',
  // AV
  'waymo', 'aurora', 'nuro', 'motional', 'gatik', 'may-mobility',
  // food tech
  'notco', 'impossible-foods', 'meati', 'ginkgo-bioworks',
  // productivity
  'asana', 'basecamp', 'teamwork',
];

async function verify(slugs) {
  const seen = new Set();
  const unique = slugs.filter(s => { if (seen.has(s)) return false; seen.add(s); return true; });
  const live = [];

  console.log(`verifying ${unique.length} unique slugs against api.ashbyhq.com...`);
  console.log('');

  for (let i = 0; i < unique.length; i++) {
    process.stdout.write(`\r  ${i + 1}/${unique.length} -- ${live.length} live`);

    const res = await get(`https://api.ashbyhq.com/posting-api/job-board/${unique[i]}`);
    if (res.status === 200) {
      try {
        const json = JSON.parse(res.body);
        if (json && (json.jobPostings !== undefined || json.jobs !== undefined)) {
          live.push(unique[i]);
        }
      } catch { /* not valid JSON */ }
    }

    await sleep(120);
  }

  process.stdout.write('\n');
  return live;
}

async function main() {
  console.log('ashby company discovery');
  console.log('');

  console.log('source 1: Google search scraping');
  const g = await fromGoogle();
  console.log('');

  console.log('source 2: Bing search scraping');
  const b = await fromBing();
  console.log('');

  console.log(`source 3: seed list (${SEED_SLUGS.length} known companies)`);
  console.log('');

  const all = [...new Set([...g, ...b, ...SEED_SLUGS])];
  console.log(`total unique slugs to verify: ${all.length}`);
  console.log('');

  const live = await verify(all);

  console.log('');
  console.log(`confirmed live: ${live.length} of ${all.length}`);
  console.log('');

  const companies = live.map((slug) => ({
    slug,
    name:          slug.replace(/[.\-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()).trim(),
    ats:           'ashby',
    jobs_api:      `https://api.ashbyhq.com/posting-api/job-board/${slug}`,
    board_url:     `https://jobs.ashbyhq.com/${slug}`,
    verified:      true,
    active:        true,
    discovered_at: new Date().toISOString(),
    source:        'api_verified',
  }));

  fs.writeFileSync(path.join(__dirname, 'ashby-companies.json'), JSON.stringify(companies, null, 2));
  console.log(`wrote ${companies.length} companies to ashby-companies.json`);
}

main().catch(err => { console.error(err.message); process.exit(1); });
