/**
 * discover-lever.js
 *
 * Lever sitemaps return very little now. We use three sources:
 *   1. scrape Google for site:jobs.lever.co results
 *   2. scrape Bing for the same
 *   3. seed list of ~600 known Lever companies
 * Then verify each against the live Lever API.
 *
 * Run: node step1-discover/discover-lever.js
 */

const https = require('https');
const fs    = require('fs');
const path  = require('path');

function get(url) {
  return new Promise((resolve) => {
    https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      }
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return get(res.headers.location).then(resolve);
      }
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end',  ()  => resolve({ status: res.statusCode, body }));
    }).on('error', () => resolve({ status: 0, body: '' }));
  });
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

function extractLeverSlugs(html) {
  const slugs = new Set();
  for (const m of html.matchAll(/jobs\.lever\.co\/([a-zA-Z0-9_-]+)/g)) {
    const s = m[1].toLowerCase();
    if (s.length > 1) slugs.add(s);
  }
  return [...slugs];
}

async function fromGoogle() {
  const found = new Set();
  const queries = [
    'site:jobs.lever.co software engineer',
    'site:jobs.lever.co backend engineer',
    'site:jobs.lever.co frontend engineer',
    'site:jobs.lever.co machine learning',
    'site:jobs.lever.co data engineer',
    'site:jobs.lever.co devops',
    'site:jobs.lever.co senior engineer',
    'site:jobs.lever.co staff engineer',
    'site:jobs.lever.co engineering manager',
    'site:jobs.lever.co product manager',
    'site:jobs.lever.co remote',
    'site:jobs.lever.co canada',
    'site:jobs.lever.co new york',
    'site:jobs.lever.co san francisco',
    'site:jobs.lever.co seattle',
    'site:jobs.lever.co london',
    'site:jobs.lever.co toronto',
    'site:jobs.lever.co fullstack',
    'site:jobs.lever.co infrastructure',
    'site:jobs.lever.co security engineer',
    'site:jobs.lever.co mobile engineer',
    'site:jobs.lever.co ios android',
  ];

  console.log(`  running ${queries.length} Google queries...`);

  for (let i = 0; i < queries.length; i++) {
    process.stdout.write(`\r  query ${i + 1}/${queries.length} -- ${found.size} slugs so far`);

    for (const start of [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]) {
      const url = `https://www.google.com/search?q=${encodeURIComponent(queries[i])}&num=10&start=${start}`;
      const res = await get(url);
      if (res.status === 200) {
        for (const s of extractLeverSlugs(res.body)) found.add(s);
      } else if (res.status === 429 || res.body.includes('unusual traffic')) {
        await sleep(5000);
        break;
      }
      await sleep(700);
    }
    await sleep(1200);
  }

  process.stdout.write('\n');
  console.log(`  found ${found.size} slugs from Google`);
  return [...found];
}

async function fromBing() {
  const found = new Set();
  const queries = [
    'site:jobs.lever.co engineer',
    'site:jobs.lever.co software',
    'site:jobs.lever.co developer',
    'site:jobs.lever.co remote',
    'site:jobs.lever.co canada',
    'site:jobs.lever.co startup',
    'site:jobs.lever.co senior',
    'site:jobs.lever.co product',
  ];

  console.log(`  running ${queries.length} Bing queries...`);

  for (let i = 0; i < queries.length; i++) {
    process.stdout.write(`\r  query ${i + 1}/${queries.length} -- ${found.size} slugs so far`);

    for (const first of [1, 11, 21, 31, 41, 51]) {
      const url = `https://www.bing.com/search?q=${encodeURIComponent(queries[i])}&count=10&first=${first}`;
      const res = await get(url);
      if (res.status === 200) {
        for (const s of extractLeverSlugs(res.body)) found.add(s);
      }
      await sleep(500);
    }
    await sleep(900);
  }

  process.stdout.write('\n');
  console.log(`  found ${found.size} slugs from Bing`);
  return [...found];
}

const SEED_SLUGS = [
  // core big tech
  'netflix', 'uber', 'twitter', 'square', 'block', 'affirm',
  'benchling', 'scale', 'waymo', 'rivian', 'lucid', 'canva',
  'afterpay', 'xero', 'seek', 'deputy', 'culture-amp', 'atlassian',
  'anthropic', 'inflection', 'adept', 'mistral', 'runway', 'pika',
  // Canadian
  'wealthsimple', 'freshbooks', 'konrad', 'benevity', 'absorb',
  'vendasta', 'hootsuite', 'unbounce', 'thinkific', 'procurify',
  'trulioo', 'dye-durham', 'push-operations', 'ritual', 'miovision',
  'coinsquare', 'clearco', 'properly', 'humi', 'collage', 'coveo',
  'dialogue', 'intellicheck', 'swiftly', 'bench', 'jobber',
  'rbc', 'td', 'scotiabank', 'bmo', 'cibc', 'manulife',
  'sunlife', 'brookfield', 'opentext', 'cgi', 'constellation-software',
  // AI
  'cohere', 'scale-ai', 'labelbox', 'weights-biases', 'anyscale',
  'modal-labs', 'together-ai', 'clarifai', 'datarobot', 'jasper',
  'writer-ai', 'copy-ai', 'moveworks', 'glean', 'vectara',
  'pinecone', 'weaviate', 'chroma', 'marqo', 'relevance-ai',
  'synthesia', 'heygen', 'd-id', 'deepbrain', 'elai',
  'murf', 'resemble', 'eleven-labs', 'wellsaid', 'speechify',
  'descript', 'podcastle', 'riverside', 'squadcast', 'zencastr',
  // fintech
  'stripe', 'braintree', 'adyen', 'checkout', 'mollie',
  'klarna', 'sezzle', 'zip', 'paidy', 'scalapay',
  'modern-treasury', 'increase', 'column', 'treasury-prime',
  'unit', 'lithic', 'bond', 'synctera',
  'socure', 'alloy', 'sardine', 'sentilink', 'unit21',
  'persona', 'veriff', 'onfido', 'jumio',
  'blend', 'stavvy', 'snapdocs', 'notarize', 'proof',
  'paxos', 'anchorage', 'bitgo', 'fireblocks', 'copper-crypto',
  'robinhood', 'webull', 'tastytrade', 'moomoo',
  'm1-finance', 'titan-invest', 'betterment', 'wealthfront', 'sofi',
  'dave', 'albert', 'brigit', 'earnin', 'current', 'step',
  'greenwood', 'majority', 'lili', 'relay', 'found',
  'bluevine', 'ondeck', 'lendio', 'nav', 'upgrade', 'avant',
  'upstart', 'commonbond', 'earnest', 'stilt',
  // dev tools
  'hashicorp', 'circleci', 'snyk', 'sonatype', 'jfrog',
  'checkmarx', 'veracode', 'synopsys',
  'lacework', 'wiz', 'orca-security', 'chainguard', 'teleport',
  'tailscale', 'netbird', 'twingate', 'zscaler',
  'render', 'fly-io', 'northflank', 'porter-dev', 'koyeb',
  'planetscale', 'neon-tech', 'fauna', 'harperdb',
  'singlestore', 'timescale', 'cockroachdb', 'yugabyte',
  'grafana', 'posthog-lever', 'sentry-lever', 'pagerduty',
  'blameless', 'firehydrant', 'rootly', 'cortex-io',
  'stoplight', 'readme', 'mintlify', 'gitbook', 'swimm',
  'retool', 'appsmith', 'tooljet', 'airplane-dev', 'pipedream',
  'zapier', 'workato', 'tray-io', 'boomi', 'celigo',
  // SaaS / HR
  'rippling', 'lattice', 'leapsome', 'workramp', 'seismic',
  'highspot', 'mindtickle', 'showpad', 'lessonly', 'docebo',
  'remote', 'deel', 'oyster-hr', 'papaya-global', 'multiplier-lever',
  'velocity-global', 'globalization-partners',
  'bamboohr', 'namely', 'justworks', 'trinet', 'paychex',
  'paycom', 'ukg', 'ceridian', 'paylocity', 'workstream',
  'homebase', 'deputy-lever', '7shifts', 'harri',
  'zoho', 'freshdesk', 'freshsales', 'freshservice',
  'pipedrive', 'close-crm', 'outreach', 'salesloft', 'gong',
  'chorus', 'clari', 'boostup', 'avoma', 'grain-io',
  'fireflies', 'airgram', 'meetgeek', 'wingman', 'cresta',
  'nice', 'verint', 'talkdesk', 'genesys', 'five9',
  'dialpad', 'ringcentral', 'vonage', '8x8',
  'hubspot', 'marketo', 'pardot', 'eloqua', 'act-on',
  'braze', 'iterable', 'klaviyo', 'drip', 'activecampaign',
  'campaign-monitor', 'sendgrid-lever', 'mailgun', 'twilio-lever',
  // health
  'oscar-health', 'modernhealth', 'lyra-health', 'spring-health',
  'headway', 'alma', 'path', 'rula', 'grow-therapy',
  'talkspace', 'betterhelp', 'cerebral', 'brightside', 'woebot',
  'calm', 'headspace',
  'omada', 'noom', 'calibrate-health', 'ro-health',
  'maven', 'progyny', 'carrot-fertility', 'kindbody',
  'city-block', 'carbon-health', 'one-medical', 'forward-health',
  'accolade', 'transcarent',
  'sword-health', 'hinge-health', 'kaia-health',
  'veeva-lever', 'medidata-lever', 'athenahealth', 'allscripts',
  'flatiron-lever', 'guardant', 'grail', 'color-genomics',
  'invitae', 'natera', 'myriad', 'ancestry', '23andme',
  // ecommerce
  'faire', 'whatnot-lever', 'depop-lever', 'poshmark', 'thredup',
  'the-realreal', 'rebag',
  'shopify-lever', 'bigcommerce', 'elastic-path', 'fabric-lever',
  'gorgias', 'tidio', 'gladly', 'yotpo', 'okendo',
  'recharge', 'skio', 'loop', 'narvar',
  'shipbob', 'shipmonk', 'deliverr', 'flexe', 'stord',
  // logistics
  'flexport', 'project44', 'fourkites', 'bringg', 'routific',
  'onfleet', 'samsara', 'motive', 'platform-science',
  'shippo', 'easypost', 'shipstation',
  'freightos', 'forto', 'sennder', 'everstream',
  // gaming
  'riot-games', 'scopely', 'jam-city', 'kabam', 'niantic',
  'rovio', 'king', 'supercell', 'playrix', 'glu',
  'playtika', 'zynga', 'gameloft', 'applovin', 'ironsource',
  // media
  'automattic', 'substack', 'ghost-org', 'buzzfeed', 'vox-media',
  'the-athletic', 'axios', 'beehiiv', 'convertkit',
  'braze-lever', 'mailchimp-lever',
  // data
  'thoughtspot', 'sigma-computing', 'mode-analytics', 'hex',
  'deepnote', 'metabase', 'redash', 'lightdash',
  'atlan', 'alation', 'collibra', 'denodo', 'starburst',
  'dremio', 'dbt-labs', 'census', 'hightouch', 'rudderstack',
  'mparticle', 'tealium', 'lytics', 'segment-lever',
  // security
  'crowdstrike', 'sentinelone', 'darktrace', 'cybereason', 'vectra',
  'exabeam', 'securonix', 'logrhythm',
  'okta', 'auth0-lever', 'ping-identity', 'sailpoint', 'saviynt',
  'cyberark', 'beyond-trust', 'delinea',
  'qualys', 'tenable', 'rapid7', 'sonatype-lever',
  'snyk-lever', 'lacework-lever', 'wiz-lever', 'orca',
  // proptech
  'procore', 'plangrid', 'fieldwire', 'raken',
  'housecall-pro', 'servicetitan', 'jobber',
  'thumbtack', 'taskrabbit', 'angi',
  // edtech
  'coursera', 'udemy', 'chegg', 'babbel',
  'preply', 'outschool', 'newsela', 'nearpod',
  // travel
  'hopper', 'skyscanner', 'sonder', 'vacasa',
  'turo', 'getaround',
  // climate
  'watershed', 'pachama', 'heirloom', 'twelve-co',
  'sunrun', 'sunnova', 'nextracker', 'enphase',
  // insurance
  'lemonade', 'root-insurance', 'hippo', 'coalition',
  'corvus', 'cowbell', 'at-bay',
  // legal
  'clio', 'kira-systems', 'ironclad', 'evisort', 'icertis',
  // AV
  'waymo', 'aurora-innovation', 'nuro', 'motional', 'pony-ai',
  'tusimple', 'gatik', 'may-mobility',
  // robotics
  'covariant', 'robust-ai', 'figure', 'apptronik', 'agility-robotics',
  // space
  'planet', 'spire', 'relativity-space', 'rocket-lab', 'astra',
  // crypto
  'coinbase', 'kraken', 'gemini', 'anchorage', 'bitgo', 'fireblocks',
  'chainalysis', 'alchemy', 'opensea', 'dapper-labs', 'immutable',
  // productivity
  'notion', 'coda', 'clickup', 'height',
  'miro', 'figma', 'lucidchart', 'whimsical', 'loom',
  // no-code
  'webflow', 'bubble', 'glideapps', 'thunkable', 'softr',
  'directus', 'strapi', 'sanity', 'contentful', 'storyblok',
  // observability
  'grafana-lever', 'honeycomb', 'lightstep', 'groundcover',
  'coroot', 'pyroscope',
];

async function verify(slugs) {
  const seen = new Set();
  const unique = slugs.filter(s => { if (seen.has(s)) return false; seen.add(s); return true; });
  const live = [];

  console.log(`verifying ${unique.length} unique slugs against api.lever.co...`);
  console.log('');

  for (let i = 0; i < unique.length; i++) {
    process.stdout.write(`\r  ${i + 1}/${unique.length} -- ${live.length} live`);
    const res = await get(`https://api.lever.co/v0/postings/${unique[i]}?mode=json`);
    if (res.status === 200) live.push(unique[i]);
    await sleep(120);
  }

  process.stdout.write('\n');
  return live;
}

async function main() {
  console.log('lever company discovery');
  console.log('');

  console.log('source 1: Google search scraping');
  const g = await fromGoogle();
  console.log('');

  console.log('source 2: Bing search scraping');
  const b = await fromBing();
  console.log('');

  console.log(`source 3: seed list (${SEED_SLUGS.length} known companies)`);
  console.log('');

  const all = [...new Set([...g, ...b, ...SEED_SLUGS])];
  console.log(`total unique slugs to verify: ${all.length}`);
  console.log('');

  const live = await verify(all);

  console.log('');
  console.log(`confirmed live: ${live.length} of ${all.length}`);
  console.log('');

  const companies = live.map((slug) => ({
    slug,
    name:          slug.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
    ats:           'lever',
    jobs_api:      `https://api.lever.co/v0/postings/${slug}?mode=json`,
    board_url:     `https://jobs.lever.co/${slug}`,
    verified:      true,
    active:        true,
    discovered_at: new Date().toISOString(),
    source:        'api_verified',
  }));

  fs.writeFileSync(path.join(__dirname, 'lever-companies.json'), JSON.stringify(companies, null, 2));
  console.log(`wrote ${companies.length} companies to lever-companies.json`);
}

main().catch(err => { console.error(err.message); process.exit(1); });
