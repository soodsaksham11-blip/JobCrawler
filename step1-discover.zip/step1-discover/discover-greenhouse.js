/**
 * discover-greenhouse.js
 *
 * Greenhouse migrated to a new domain: job-boards.greenhouse.io
 * The old boards.greenhouse.io sitemap is gone but the new domain
 * has its own sitemap. We also scrape Google for additional slugs
 * since Google has indexed thousands of these pages.
 *
 * Strategy:
 *   1. fetch job-boards.greenhouse.io/sitemap.xml  (new domain)
 *   2. scrape Google for site:job-boards.greenhouse.io results
 *   3. scrape Google for site:boards.greenhouse.io results (old, still indexed)
 *   4. verify each slug against the boards-api which still works for both
 *   5. write greenhouse-companies.json
 *
 * Run: node step1-discover/discover-greenhouse.js
 */

const https = require('https');
const fs    = require('fs');
const path  = require('path');


// ---------------------------------------------------------------------------
// HTTP
// ---------------------------------------------------------------------------

function get(url, extraHeaders = {}) {
  return new Promise((resolve) => {
    const opts = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        ...extraHeaders,
      },
    };
    https.get(url, opts, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return get(res.headers.location, extraHeaders).then(resolve);
      }
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end',  ()  => resolve({ status: res.statusCode, body }));
    }).on('error', () => resolve({ status: 0, body: '' }));
  });
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function extractGreenHouseSlugs(html) {
  const slugs = new Set();
  const patterns = [
    /job-boards\.greenhouse\.io\/([a-zA-Z0-9_-]+)/g,
    /boards\.greenhouse\.io\/([a-zA-Z0-9_-]+)/g,
  ];
  const skip = new Set(['jobs', 'sitemap', 'embed', 'api', 'robots']);
  for (const pattern of patterns) {
    for (const m of html.matchAll(pattern)) {
      const s = m[1].toLowerCase();
      if (s.length > 1 && !skip.has(s)) slugs.add(s);
    }
  }
  return [...slugs];
}


// ---------------------------------------------------------------------------
// Source 1: new Greenhouse sitemap
// ---------------------------------------------------------------------------

async function fromNewSitemap() {
  console.log('  trying job-boards.greenhouse.io/sitemap.xml ...');
  const res = await get('https://job-boards.greenhouse.io/sitemap.xml');
  if (res.status !== 200) {
    console.log(`  status ${res.status}, skipping`);
    return [];
  }
  const slugs = extractGreenHouseSlugs(res.body);
  console.log(`  found ${slugs.length} slugs`);
  return slugs;
}


// ---------------------------------------------------------------------------
// Source 2: Google scraping
//
// Google has indexed thousands of Greenhouse job boards. We query
// multiple search terms to maximise coverage. Each query can return
// up to 100 results.
// ---------------------------------------------------------------------------

async function fromGoogle() {
  const found = new Set();

  const queries = [
    'site:job-boards.greenhouse.io',
    'site:boards.greenhouse.io software engineer',
    'site:boards.greenhouse.io backend engineer',
    'site:boards.greenhouse.io frontend engineer',
    'site:boards.greenhouse.io fullstack engineer',
    'site:boards.greenhouse.io machine learning engineer',
    'site:boards.greenhouse.io data engineer',
    'site:boards.greenhouse.io devops engineer',
    'site:boards.greenhouse.io senior engineer',
    'site:boards.greenhouse.io staff engineer',
    'site:boards.greenhouse.io engineering manager',
    'site:boards.greenhouse.io product manager',
    'site:boards.greenhouse.io remote',
    'site:boards.greenhouse.io canada',
    'site:boards.greenhouse.io new york',
    'site:boards.greenhouse.io san francisco',
    'site:boards.greenhouse.io seattle',
    'site:boards.greenhouse.io london',
    'site:boards.greenhouse.io toronto',
    'site:job-boards.greenhouse.io software',
    'site:job-boards.greenhouse.io engineer',
    'site:job-boards.greenhouse.io remote',
  ];

  console.log(`  running ${queries.length} Google queries...`);

  for (let i = 0; i < queries.length; i++) {
    const q = queries[i];
    process.stdout.write(`\r  query ${i + 1}/${queries.length} -- ${found.size} slugs so far`);

    // start=0, 10, 20 to get more results per query
    for (const start of [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]) {
      const url = `https://www.google.com/search?q=${encodeURIComponent(q)}&num=10&start=${start}`;
      const res = await get(url);

      if (res.status === 200) {
        for (const s of extractGreenHouseSlugs(res.body)) found.add(s);
      } else if (res.status === 429 || res.body.includes('unusual traffic')) {
        // Google is rate limiting -- back off
        await sleep(5000);
        break;
      }

      await sleep(800);
    }

    await sleep(1200);
  }

  process.stdout.write('\n');
  console.log(`  found ${found.size} unique slugs from Google`);
  return [...found];
}


// ---------------------------------------------------------------------------
// Source 3: Bing scraping (different index than Google, more slugs)
// ---------------------------------------------------------------------------

async function fromBing() {
  const found = new Set();

  const queries = [
    'site:job-boards.greenhouse.io',
    'site:boards.greenhouse.io engineer',
    'site:boards.greenhouse.io software',
    'site:boards.greenhouse.io developer',
    'site:boards.greenhouse.io tech',
    'site:boards.greenhouse.io startup',
    'site:boards.greenhouse.io remote jobs',
    'site:boards.greenhouse.io canada jobs',
  ];

  console.log(`  running ${queries.length} Bing queries...`);

  for (let i = 0; i < queries.length; i++) {
    const q = queries[i];
    process.stdout.write(`\r  query ${i + 1}/${queries.length} -- ${found.size} slugs so far`);

    for (const first of [1, 11, 21, 31, 41]) {
      const url = `https://www.bing.com/search?q=${encodeURIComponent(q)}&count=10&first=${first}`;
      const res = await get(url);
      if (res.status === 200) {
        for (const s of extractGreenHouseSlugs(res.body)) found.add(s);
      }
      await sleep(600);
    }

    await sleep(1000);
  }

  process.stdout.write('\n');
  console.log(`  found ${found.size} unique slugs from Bing`);
  return [...found];
}


// ---------------------------------------------------------------------------
// Source 4: hardcoded seed list
// Covers major tech companies that are confirmed on Greenhouse.
// This ensures we never miss the obvious ones regardless of search results.
// ---------------------------------------------------------------------------

const SEED_SLUGS = [
  'shopify', 'stripe', 'airbnb', 'lyft', 'pinterest', 'dropbox',
  'zendesk', 'hubspot', 'twilio', 'sendgrid', 'segment', 'mixpanel',
  'figma', 'notion', 'airtable', 'asana', 'gusto', 'brex', 'ramp',
  'mercury', 'carta', 'plaid', 'coinbase', 'kraken', 'instacart',
  'doordash', 'datadog', 'newrelic', 'splunk', 'elastic', 'mongodb',
  'confluent', 'databricks', 'snowflake', 'fivetran', 'hashicorp',
  'circleci', 'gitlab', 'atlassian', 'intercom', 'openai', 'duolingo',
  'grammarly', 'canva', 'miro', 'loom', 'descript', 'peloton',
  'roblox', 'unity', 'riot-games', 'scopely', 'amplitude', 'heap',
  'fullstory', 'flexport', 'opendoor', 'compass', 'redfin',
  'lemonade', 'root', 'hippo', 'coursera', 'chegg', 'aurora',
  'nuro', 'zoox', 'automattic', 'benchling', 'veeva', 'medidata',
  'tempus', 'whatnot', 'depop', 'hopper', 'crowdstrike', 'sentinelone',
  'darktrace', 'chainalysis', 'alchemy', 'opensea', 'dapper-labs',
  'watershed', 'pachama', 'planet', 'spire', 'kira-systems',
  'wealthsimple', 'hootsuite', 'lightspeed', 'benevity', 'clio',
  'd2l', 'vidyard', 'geotab', 'freshbooks', 'absorb', 'vendasta',
  'nuvei', 'koho', 'ecobee', 'thinkific', 'unbounce', 'procurify',
  'cohere', 'scale', 'labelbox', 'anyscale', 'modal', 'weights-biases',
  'affirm', 'faire', 'marqeta', 'chime', 'robinhood', 'unit', 'lithic',
  'snyk', 'lacework', 'wiz', 'chainguard', 'teleport', 'tailscale',
  'rippling', 'lattice', 'leapsome', 'culture-amp', 'seismic',
  'highspot', 'mindtickle', 'remote', 'deel', 'oyster', 'bamboohr',
  'oscar', 'modernhealth', 'lyra-health', 'spring-health', 'flatiron',
  'duolingo', 'peloton', 'whoop', 'niantic', 'rovio', 'supercell',
  'applovin', 'amplitude', 'contentsquare', 'project44', 'samsara',
  'lemonade', 'coalition', 'corvus', 'procore', 'servicetitan',
  'housecall-pro', 'thumbtack', 'ironclad', 'evisort', 'lexion',
  'veeva', 'sword-health', 'hinge-health', 'omada', 'noom',
  'airbnb', 'sonder', 'vacasa', 'hopper', 'turo', 'discord',
  'reddit', 'quora', 'substack', 'beehiiv', 'convertkit',
  'anthropic', 'adept', 'inflection', 'jasper', 'writer',
  'glean', 'moveworks', 'vectara', 'pinecone', 'weaviate',
  'dbt-labs', 'hex', 'metabase', 'lightdash', 'thoughtspot',
  'starburst', 'dremio', 'census', 'hightouch', 'rudderstack',
  'anduril', 'shield-ai', 'palantir', 'rebellion-defense',
  'relativity-space', 'rocket-lab', 'planet-labs', 'spire-global',
  'rivian', 'motional', 'tusimple', 'gatik', 'may-mobility',
  'ginkgo-bioworks', 'zymergen', 'indigo-agriculture', 'pivot-bio',
  'impossible-foods', 'notco', 'eat-just', 'meati',
  'sunrun', 'sunnova', 'heirloom', 'charm-industrial',
  'lemonade', 'at-bay', 'cowbell', 'pie-insurance',
  'prodigy-finance', 'stilt', 'upgrade', 'upstart', 'earnest',
  'opentable', 'resy', 'tock', 'toast', 'lightspeed-restaurant',
  'sevenrooms', 'grubhub', 'caviar', 'doordash', 'postmates',
  'flatiron', 'guardant', 'grail', 'color', 'invitae', 'natera',
  'headway', 'alma', 'path', 'rula', 'grow-therapy',
  'omnirobotic', 'covariant', 'robust-ai', 'figure', 'apptronik',
  'benchling', 'synthego', 'emerald-cloud-lab', 'strateos',
  'nuro', 'pony-ai', 'embark', 'kodiak', 'locomation',
  'andurilindustries', 'shield', 'sievert', 'prima',
  'remotecom', 'deelio', 'papaya-global', 'multiplier',
  'brainfinance', 'lendbuzz', 'avant', 'prosper', 'marlette',
  'freshworks', 'pipedrive', 'close', 'outreach', 'salesloft',
  'gong', 'chorus', 'clari', 'boostup', 'avoma',
  'braze', 'iterable', 'klaviyo', 'drip', 'activecampaign',
  'yotpo', 'okendo', 'recharge', 'skio', 'loop',
  'shipbob', 'shipmonk', 'deliverr', 'flexe', 'flowspace',
  'foursuites', 'placemakr', 'mint-house', 'lyric', 'domio',
  'retool', 'webflow', 'framer', 'bubble', 'glideapps',
  'stytch', 'clerk', 'workos', 'permit', 'auth0',
  'qualys', 'tenable', 'rapid7', 'sonatype', 'jfrog',
  'semgrep', 'checkmarx', 'sonarqube', 'mend', 'endor',
  'axonius', 'orca', 'wiz', 'ermetic', 'sonrai',
  'vectra', 'exabeam', 'securonix', 'logrhythm', 'devo',
  'okta', 'ping', 'sailpoint', 'saviynt', 'cyberark',
  'delinea', 'beyond-trust', 'one-identity', 'hashicorp',
  'pagerduty', 'opsgenie', 'blameless', 'firehydrant', 'rootly',
  'grafana', 'posthog', 'highlight', 'honeycomb', 'lightstep',
  'dataiku', 'alteryx', 'rapidminer', 'h2o', 'domino-data',
  'tecton', 'feast', 'hopsworks', 'feature-store',
  'bentoml', 'seldon', 'modzy', 'algorithmia', 'paperspace',
  'lambda-labs', 'coreweave', 'runpod', 'vast-data',
  'netlify', 'vercel-gh', 'fastly', 'cloudflare-gh',
  'vultr', 'linode', 'digitalocean', 'hetzner-gh',
  'pulumi', 'crossplane', 'upbound', 'argo-proj',
  'buildkite', 'semaphore-ci', 'drone-io', 'woodpecker',
  'sourcegraph', 'codacy', 'codecov', 'deepsource',
  'snyk', 'dependabot', 'renovate', 'mend-io',
  'jetbrains', 'intellij', 'rider', 'goland',
  'postman', 'insomnia', 'hoppscotch', 'bruno',
  'supabase', 'neon', 'planetscale', 'turso', 'xata',
  'cockroachdb', 'yugabyte', 'singlestore', 'timescale',
  'redis', 'dragonflydb', 'keydb', 'momento',
  'confluent', 'redpanda', 'warpstream', 'sequin',
  'airbyte', 'fivetran', 'stitch', 'matillion',
  'dbt-labs', 'transform', 'rill', 'cube',
  'preset', 'atlan', 'alation', 'collibra',
  'monte-carlo', 'bigeye', 'acceldata', 'metaplane',
  'great-expectations', 'soda', 'datafold', 'anomalo',
  'comet', 'neptune', 'guild', 'valohai',
  'huggingface', 'replicate', 'banana', 'beam',
  'modal', 'together', 'anyscale', 'ray-project',
  'determined-ai', 'flyte', 'metaflow', 'zenml',
  'kedro', 'mlflow', 'dvc', 'cml',
];


// ---------------------------------------------------------------------------
// Verification
// ---------------------------------------------------------------------------

async function verify(slugs) {
  const live = [];
  const seen = new Set();
  const unique = slugs.filter(s => {
    if (seen.has(s)) return false;
    seen.add(s);
    return true;
  });

  console.log(`verifying ${unique.length} unique slugs against boards-api.greenhouse.io...`);
  console.log('(this takes several minutes)');
  console.log('');

  for (let i = 0; i < unique.length; i++) {
    const slug = unique[i];
    process.stdout.write(`\r  ${i + 1}/${unique.length} -- ${live.length} live`);

    // the API endpoint still works for both old and new domain slugs
    const res = await get(`https://boards-api.greenhouse.io/v1/boards/${slug}/jobs`);
    if (res.status === 200) live.push(slug);

    await sleep(120);
  }

  process.stdout.write('\n');
  return live;
}


// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  console.log('greenhouse company discovery');
  console.log('');

  console.log('source 1: new sitemap (job-boards.greenhouse.io)');
  const sitemapSlugs = await fromNewSitemap();
  console.log('');

  console.log('source 2: Google search scraping');
  const googleSlugs = await fromGoogle();
  console.log('');

  console.log('source 3: Bing search scraping');
  const bingSlugs = await fromBing();
  console.log('');

  console.log(`source 4: seed list (${SEED_SLUGS.length} known companies)`);
  console.log('');

  const all = [...new Set([
    ...sitemapSlugs,
    ...googleSlugs,
    ...bingSlugs,
    ...SEED_SLUGS,
  ])];

  console.log(`total unique slugs to verify: ${all.length}`);
  console.log('');

  const live = await verify(all);

  console.log('');
  console.log(`confirmed live: ${live.length} of ${all.length}`);
  console.log('');

  const companies = live.map((slug) => ({
    slug,
    name:          slugToName(slug),
    ats:           'greenhouse',
    jobs_api:      `https://boards-api.greenhouse.io/v1/boards/${slug}/jobs?content=true`,
    board_url:     `https://job-boards.greenhouse.io/${slug}`,
    verified:      true,
    active:        true,
    discovered_at: new Date().toISOString(),
    source:        'api_verified',
  }));

  const out = path.join(__dirname, 'greenhouse-companies.json');
  fs.writeFileSync(out, JSON.stringify(companies, null, 2));
  console.log(`wrote ${companies.length} companies to greenhouse-companies.json`);
}

function slugToName(slug) {
  return slug.replace(/[-_]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
