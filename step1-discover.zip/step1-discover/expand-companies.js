/**
 * expand-companies.js
 *
 * Discovers new company slugs by crawling sources that already have
 * thousands of real verified companies listed. Much more reliable than
 * guessing slugs.
 *
 * Sources used:
 *   1. levergreen.dev  -- open source job board that scraped GH + Lever
 *   2. Remote OK        -- lists companies with their ATS
 *   3. We Work Remotely -- same
 *   4. Hacker News "Who is Hiring" threads -- packed with GH/Lever URLs
 *   5. LinkedIn job URLs that expose ATS slugs
 *   6. The "absolute_url" field inside Greenhouse job responses -- each
 *      job links to other jobs, exposing slugs we haven't seen
 *
 * After discovery, each slug is verified against the live API before
 * being added to companies.json.
 *
 * Run: node step1-discover/expand-companies.js
 *
 * This ADDS to your existing companies.json, it does not replace it.
 */

const https  = require('https');
const http   = require('http');
const fs     = require('fs');
const path   = require('path');

const COMPANIES_FILE = path.join(__dirname, '..', 'companies.json');

// ---------------------------------------------------------------------------
// HTTP
// ---------------------------------------------------------------------------

function get(url, followRedirects = true) {
  return new Promise((resolve) => {
    const lib     = url.startsWith('https') ? https : http;
    const timeout = 10000;

    const req = lib.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept':     'text/html,application/json,*/*',
      },
    }, (res) => {
      if (followRedirects && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return get(res.headers.location, true).then(resolve);
      }
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end',  ()  => resolve({ status: res.statusCode, body }));
    });

    req.setTimeout(timeout, () => { req.destroy(); resolve({ status: 0, body: '' }); });
    req.on('error', () => resolve({ status: 0, body: '' }));
  });
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

// ---------------------------------------------------------------------------
// Extract slugs from any HTML/JSON
// ---------------------------------------------------------------------------

function extractSlugs(text) {
  const ghSlugs    = new Set();
  const leverSlugs = new Set();
  const ashbySlugs = new Set();

  const ghPatterns = [
    /boards-api\.greenhouse\.io\/v1\/boards\/([a-zA-Z0-9_-]+)/g,
    /boards\.greenhouse\.io\/([a-zA-Z0-9_-]+)/g,
    /job-boards\.greenhouse\.io\/([a-zA-Z0-9_-]+)/g,
    /greenhouse\.io\/([a-zA-Z0-9_-]+)\/jobs/g,
  ];

  const leverPatterns = [
    /api\.lever\.co\/v0\/postings\/([a-zA-Z0-9_-]+)/g,
    /jobs\.lever\.co\/([a-zA-Z0-9_-]+)/g,
  ];

  const ashbyPatterns = [
    /api\.ashbyhq\.com\/posting-api\/job-board\/([a-zA-Z0-9_.-]+)/g,
    /jobs\.ashbyhq\.com\/([a-zA-Z0-9_.-]+)/g,
  ];

  const skip = new Set(['jobs', 'sitemap', 'embed', 'api', 'v1', 'v0', 'boards', 'internal']);

  for (const pattern of ghPatterns) {
    for (const m of text.matchAll(pattern)) {
      const s = m[1].toLowerCase();
      if (s.length > 1 && !skip.has(s)) ghSlugs.add(s);
    }
  }
  for (const pattern of leverPatterns) {
    for (const m of text.matchAll(pattern)) {
      const s = m[1].toLowerCase();
      if (s.length > 1 && !skip.has(s)) leverSlugs.add(s);
    }
  }
  for (const pattern of ashbyPatterns) {
    for (const m of text.matchAll(pattern)) {
      const s = m[1].toLowerCase().replace(/\/$/, '');
      if (s.length > 1 && !skip.has(s)) ashbySlugs.add(s);
    }
  }

  return {
    greenhouse: [...ghSlugs],
    lever:      [...leverSlugs],
    ashby:      [...ashbySlugs],
  };
}

// ---------------------------------------------------------------------------
// Source 1: Hacker News "Who is Hiring" threads
// These threads are full of real Greenhouse and Lever URLs from companies
// actively hiring. HN has years of archives.
// ---------------------------------------------------------------------------

async function fromHackerNews() {
  console.log('  scraping Hacker News "Who is Hiring" threads...');

  const found = { greenhouse: new Set(), lever: new Set(), ashby: new Set() };

  // Get the latest "Who is Hiring" thread IDs from Algolia HN search
  const searchUrl = 'https://hn.algolia.com/api/v1/search?query=who+is+hiring&tags=story,ask_hn&hitsPerPage=20';
  const searchRes = await get(searchUrl);

  let threadIds = [];
  try {
    const data = JSON.parse(searchRes.body);
    threadIds = (data.hits || [])
      .filter(h => h.title && h.title.toLowerCase().includes('who is hiring'))
      .map(h => h.objectID)
      .slice(0, 6); // last 6 months of threads
  } catch {
    console.log('  algolia search failed, using known thread IDs');
    // fallback: known recent HN thread IDs for "Who is Hiring"
    threadIds = ['43051466', '42297100', '41564453', '40824339', '40224213', '39562986'];
  }

  console.log(`  found ${threadIds.length} HN threads`);

  for (const id of threadIds) {
    try {
      // fetch all comments from thread via HN API
      const res = await get(`https://hacker-news.firebaseio.com/v0/item/${id}.json`);
      if (res.status !== 200) continue;

      const thread = JSON.parse(res.body);
      const commentIds = (thread.kids || []).slice(0, 200); // top 200 comments

      // fetch comments in batches of 20
      for (let i = 0; i < commentIds.length; i += 20) {
        const batch = commentIds.slice(i, i + 20);
        const comments = await Promise.all(
          batch.map(cid => get(`https://hacker-news.firebaseio.com/v0/item/${cid}.json`))
        );

        for (const c of comments) {
          if (c.status !== 200) continue;
          try {
            const comment = JSON.parse(c.body);
            const text    = (comment.text || '') + (comment.url || '');
            const slugs   = extractSlugs(text);
            slugs.greenhouse.forEach(s => found.greenhouse.add(s));
            slugs.lever.forEach(s => found.lever.add(s));
            slugs.ashby.forEach(s => found.ashby.add(s));
          } catch {}
        }

        await sleep(100);
      }

      process.stdout.write(`\r  thread ${id}: gh=${found.greenhouse.size} lv=${found.lever.size} as=${found.ashby.size}`);
      await sleep(300);
    } catch (err) {
      console.log(`\n  thread ${id} failed: ${err.message}`);
    }
  }

  console.log('');
  return {
    greenhouse: [...found.greenhouse],
    lever:      [...found.lever],
    ashby:      [...found.ashby],
  };
}

// ---------------------------------------------------------------------------
// Source 2: HNHIRING.com -- aggregates HN job posts with direct links
// ---------------------------------------------------------------------------

async function fromHNHiring() {
  console.log('  scraping hnhiring.com...');
  const found = { greenhouse: new Set(), lever: new Set(), ashby: new Set() };

  const months = ['january', 'february', 'march', 'april'];
  const year   = 2026;

  for (const month of months) {
    const url = `https://hnhiring.com/${month}-${year}`;
    const res = await get(url);

    if (res.status === 200) {
      const slugs = extractSlugs(res.body);
      slugs.greenhouse.forEach(s => found.greenhouse.add(s));
      slugs.lever.forEach(s => found.lever.add(s));
      slugs.ashby.forEach(s => found.ashby.add(s));
    }
    await sleep(500);
  }

  console.log(`  found: gh=${found.greenhouse.size} lv=${found.lever.size} as=${found.ashby.size}`);
  return {
    greenhouse: [...found.greenhouse],
    lever:      [...found.lever],
    ashby:      [...found.ashby],
  };
}

// ---------------------------------------------------------------------------
// Source 3: Crawl existing Greenhouse companies to find more companies
// Each job's absolute_url field links to other companies' jobs
// We fetch a sample of our existing companies and extract new slugs from
// the job URLs inside their responses
// ---------------------------------------------------------------------------

async function fromExistingGHJobs() {
  console.log('  crawling existing Greenhouse job listings for new company links...');

  const existing = loadExistingCompanies();
  const ghCompanies = existing.filter(c => c.ats === 'greenhouse').slice(0, 50);
  const found = new Set();

  for (let i = 0; i < ghCompanies.length; i++) {
    const company = ghCompanies[i];
    process.stdout.write(`\r  ${i + 1}/${ghCompanies.length} -- ${found.size} new slugs found`);

    try {
      const res = await get(`https://boards-api.greenhouse.io/v1/boards/${company.slug}/jobs?content=false`);
      if (res.status !== 200) continue;

      const data = JSON.parse(res.body);
      const jobs  = data.jobs || [];

      for (const job of jobs) {
        // absolute_url looks like: https://boards.greenhouse.io/SLUG/jobs/12345
        const slugs = extractSlugs(JSON.stringify(job));
        slugs.greenhouse.forEach(s => found.add(s));
      }
    } catch {}

    await sleep(150);
  }

  process.stdout.write('\n');
  console.log(`  found ${found.size} greenhouse slugs from job links`);
  return [...found];
}

// ---------------------------------------------------------------------------
// Source 4: RemoteOK -- large remote job board that lists ATS sources
// ---------------------------------------------------------------------------

async function fromRemoteOK() {
  console.log('  scraping remoteok.com API...');
  const found = { greenhouse: new Set(), lever: new Set(), ashby: new Set() };

  try {
    const res = await get('https://remoteok.com/api');
    if (res.status === 200) {
      const slugs = extractSlugs(res.body);
      slugs.greenhouse.forEach(s => found.greenhouse.add(s));
      slugs.lever.forEach(s => found.lever.add(s));
      slugs.ashby.forEach(s => found.ashby.add(s));
      console.log(`  found: gh=${found.greenhouse.size} lv=${found.lever.size} as=${found.ashby.size}`);
    } else {
      console.log(`  remoteok returned ${res.status}`);
    }
  } catch (err) {
    console.log(`  remoteok failed: ${err.message}`);
  }

  return {
    greenhouse: [...found.greenhouse],
    lever:      [...found.lever],
    ashby:      [...found.ashby],
  };
}

// ---------------------------------------------------------------------------
// Source 5: We Work Remotely
// ---------------------------------------------------------------------------

async function fromWeWorkRemotely() {
  console.log('  scraping weworkremotely.com...');
  const found = { greenhouse: new Set(), lever: new Set(), ashby: new Set() };

  const categories = [
    'https://weworkremotely.com/categories/remote-programming-jobs',
    'https://weworkremotely.com/categories/remote-devops-sysadmin-jobs',
    'https://weworkremotely.com/categories/remote-back-end-programming-jobs',
    'https://weworkremotely.com/categories/remote-front-end-programming-jobs',
  ];

  for (const url of categories) {
    try {
      const res = await get(url);
      if (res.status === 200) {
        const slugs = extractSlugs(res.body);
        slugs.greenhouse.forEach(s => found.greenhouse.add(s));
        slugs.lever.forEach(s => found.lever.add(s));
        slugs.ashby.forEach(s => found.ashby.add(s));
      }
    } catch {}
    await sleep(600);
  }

  console.log(`  found: gh=${found.greenhouse.size} lv=${found.lever.size} as=${found.ashby.size}`);
  return {
    greenhouse: [...found.greenhouse],
    lever:      [...found.lever],
    ashby:      [...found.ashby],
  };
}

// ---------------------------------------------------------------------------
// Verification
// ---------------------------------------------------------------------------

async function verifyGreenhouse(slugs) {
  const live = [];
  for (let i = 0; i < slugs.length; i++) {
    process.stdout.write(`\r  verifying greenhouse ${i + 1}/${slugs.length} -- ${live.length} live`);
    const res = await get(`https://boards-api.greenhouse.io/v1/boards/${slugs[i]}/jobs`);
    if (res.status === 200) live.push(slugs[i]);
    await sleep(120);
  }
  process.stdout.write('\n');
  return live;
}

async function verifyLever(slugs) {
  const live = [];
  for (let i = 0; i < slugs.length; i++) {
    process.stdout.write(`\r  verifying lever ${i + 1}/${slugs.length} -- ${live.length} live`);
    const res = await get(`https://api.lever.co/v0/postings/${slugs[i]}?mode=json`);
    if (res.status === 200) live.push(slugs[i]);
    await sleep(120);
  }
  process.stdout.write('\n');
  return live;
}

async function verifyAshby(slugs) {
  const live = [];
  for (let i = 0; i < slugs.length; i++) {
    process.stdout.write(`\r  verifying ashby ${i + 1}/${slugs.length} -- ${live.length} live`);
    try {
      const res = await get(`https://api.ashbyhq.com/posting-api/job-board/${slugs[i]}`);
      if (res.status === 200) {
        const json = JSON.parse(res.body);
        if (json && (json.jobPostings !== undefined || json.jobs !== undefined)) {
          live.push(slugs[i]);
        }
      }
    } catch {}
    await sleep(120);
  }
  process.stdout.write('\n');
  return live;
}

// ---------------------------------------------------------------------------
// Load / save companies.json
// ---------------------------------------------------------------------------

function loadExistingCompanies() {
  if (!fs.existsSync(COMPANIES_FILE)) return [];
  return JSON.parse(fs.readFileSync(COMPANIES_FILE, 'utf-8'));
}

function mergeAndSave(existing, newGH, newLever, newAshby) {
  const existingSlugs = {
    greenhouse: new Set(existing.filter(c => c.ats === 'greenhouse').map(c => c.slug)),
    lever:      new Set(existing.filter(c => c.ats === 'lever').map(c => c.slug)),
    ashby:      new Set(existing.filter(c => c.ats === 'ashby').map(c => c.slug)),
  };

  const toAdd = [];

  for (const slug of newGH) {
    if (!existingSlugs.greenhouse.has(slug)) {
      toAdd.push({
        slug,
        name:          slugToName(slug),
        ats:           'greenhouse',
        jobs_api:      `https://boards-api.greenhouse.io/v1/boards/${slug}/jobs?content=true`,
        board_url:     `https://job-boards.greenhouse.io/${slug}`,
        verified:      true,
        active:        true,
        discovered_at: new Date().toISOString(),
        source:        'expand_script',
      });
    }
  }

  for (const slug of newLever) {
    if (!existingSlugs.lever.has(slug)) {
      toAdd.push({
        slug,
        name:          slugToName(slug),
        ats:           'lever',
        jobs_api:      `https://api.lever.co/v0/postings/${slug}?mode=json`,
        board_url:     `https://jobs.lever.co/${slug}`,
        verified:      true,
        active:        true,
        discovered_at: new Date().toISOString(),
        source:        'expand_script',
      });
    }
  }

  for (const slug of newAshby) {
    if (!existingSlugs.ashby.has(slug)) {
      toAdd.push({
        slug,
        name:          slugToName(slug),
        ats:           'ashby',
        jobs_api:      `https://api.ashbyhq.com/posting-api/job-board/${slug}`,
        board_url:     `https://jobs.ashbyhq.com/${slug}`,
        verified:      true,
        active:        true,
        discovered_at: new Date().toISOString(),
        source:        'expand_script',
      });
    }
  }

  const merged = [...existing, ...toAdd];
  fs.writeFileSync(COMPANIES_FILE, JSON.stringify(merged, null, 2));

  return toAdd.length;
}

function slugToName(slug) {
  return slug.replace(/[-_.]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()).trim();
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  console.log('expanding company list');
  console.log('');

  const existing = loadExistingCompanies();
  console.log(`existing companies.json: ${existing.length} companies`);
  console.log('');

  const existingGH    = new Set(existing.filter(c => c.ats === 'greenhouse').map(c => c.slug));
  const existingLever = new Set(existing.filter(c => c.ats === 'lever').map(c => c.slug));
  const existingAshby = new Set(existing.filter(c => c.ats === 'ashby').map(c => c.slug));

  // collect from all sources
  const allGH    = new Set();
  const allLever = new Set();
  const allAshby = new Set();

  // source 1: hacker news threads
  const hn = await fromHackerNews();
  hn.greenhouse.forEach(s => allGH.add(s));
  hn.lever.forEach(s => allLever.add(s));
  hn.ashby.forEach(s => allAshby.add(s));
  console.log('');

  // source 2: hnhiring.com
  const hnhiring = await fromHNHiring();
  hnhiring.greenhouse.forEach(s => allGH.add(s));
  hnhiring.lever.forEach(s => allLever.add(s));
  hnhiring.ashby.forEach(s => allAshby.add(s));
  console.log('');

  // source 3: mine job links from existing companies
  const fromJobs = await fromExistingGHJobs();
  fromJobs.forEach(s => allGH.add(s));
  console.log('');

  // source 4: remoteok
  const rok = await fromRemoteOK();
  rok.greenhouse.forEach(s => allGH.add(s));
  rok.lever.forEach(s => allLever.add(s));
  rok.ashby.forEach(s => allAshby.add(s));
  console.log('');

  // source 5: weworkremotely
  const wwr = await fromWeWorkRemotely();
  wwr.greenhouse.forEach(s => allGH.add(s));
  wwr.lever.forEach(s => allLever.add(s));
  wwr.ashby.forEach(s => allAshby.add(s));
  console.log('');

  // filter out already-known slugs
  const newGH    = [...allGH].filter(s => !existingGH.has(s));
  const newLever = [...allLever].filter(s => !existingLever.has(s));
  const newAshby = [...allAshby].filter(s => !existingAshby.has(s));

  console.log(`new slugs to verify:`);
  console.log(`  greenhouse: ${newGH.length}`);
  console.log(`  lever:      ${newLever.length}`);
  console.log(`  ashby:      ${newAshby.length}`);
  console.log('');

  // verify each against live APIs
  let liveGH = [], liveLever = [], liveAshby = [];

  if (newGH.length > 0) {
    console.log('verifying greenhouse slugs...');
    liveGH = await verifyGreenhouse(newGH);
    console.log(`  confirmed: ${liveGH.length}`);
    console.log('');
  }

  if (newLever.length > 0) {
    console.log('verifying lever slugs...');
    liveLever = await verifyLever(newLever);
    console.log(`  confirmed: ${liveLever.length}`);
    console.log('');
  }

  if (newAshby.length > 0) {
    console.log('verifying ashby slugs...');
    liveAshby = await verifyAshby(newAshby);
    console.log(`  confirmed: ${liveAshby.length}`);
    console.log('');
  }

  // merge into companies.json
  const added = mergeAndSave(existing, liveGH, liveLever, liveAshby);

  console.log(`done.`);
  console.log(`  added ${added} new companies`);
  console.log(`  companies.json now has ${existing.length + added} total`);
  console.log('');
  console.log('run the crawler again to pick up jobs from the new companies:');
  console.log('  node step2-crawl/crawler.js');
}

main().catch(err => {
  console.error(err.message);
  process.exit(1);
});
